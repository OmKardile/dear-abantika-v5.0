import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence, useMotionValue, useTransform } from "motion/react";
import {
  Home, Flower2, BookOpen, Droplets, Settings,
  Plus, Search, Bell, ChevronLeft, ChevronRight,
  Star, Download, Upload, Check, Pencil, Trash2,
  BarChart3, Smile, X, Zap, AlertTriangle,
  ArrowUpDown, ShoppingBag, Filter,
} from "lucide-react";
import { BarChart, Bar, XAxis, ResponsiveContainer, Cell, Tooltip } from "recharts";

// ─── Global CSS ───────────────────────────────────────────────────────────────

const G = `
  @keyframes waveMove { 0%{transform:translateX(0)} 100%{transform:translateX(-50%)} }
  @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-5px)} }
  .hs { scrollbar-width:none; }
  .hs::-webkit-scrollbar { display:none; }
  * { -webkit-tap-highlight-color:transparent; }
`;

// ─── Themes ───────────────────────────────────────────────────────────────────

interface T {
  name:string; emoji:string;
  bg:string; bgEl:string;
  card:string; cardHi:string; glass:string;
  fg:string; fg2:string; fg3:string;
  ac:string; acM:string; acS:string;
  ok:string; warn:string; err:string;
  bd:string; div:string;
  sw:string;
}

const THEMES: Record<string,T> = {
  monoNoir:{name:"Mono Noir",emoji:"🖤",bg:"#080808",bgEl:"#101010",card:"#141414",cardHi:"#1C1C1C",glass:"rgba(20,20,20,0.88)",fg:"#F2F2F2",fg2:"#888",fg3:"#444",ac:"#E0E0E0",acM:"#888",acS:"#1E1E1E",ok:"#4ADE80",warn:"#FBBF24",err:"#F87171",bd:"rgba(255,255,255,0.07)",div:"rgba(255,255,255,0.04)",sw:"#2A2A2A"},
  sage:{name:"Sage",emoji:"🌿",bg:"#08110D",bgEl:"#0D1810",card:"#111C15",cardHi:"#192A1F",glass:"rgba(17,28,21,0.88)",fg:"#D8EDD8",fg2:"#6A9270",fg3:"#3A5C40",ac:"#5DBE72",acM:"#3A7A4A",acS:"#142219",ok:"#4ADE80",warn:"#FBBF24",err:"#F87171",bd:"rgba(93,190,114,0.10)",div:"rgba(93,190,114,0.05)",sw:"#5DBE72"},
  lavender:{name:"Lavender",emoji:"💜",bg:"#0C0C18",bgEl:"#111122",card:"#141428",cardHi:"#1C1C38",glass:"rgba(20,20,40,0.88)",fg:"#E2DAFF",fg2:"#8080C0",fg3:"#484880",ac:"#9B72F0",acM:"#6644CC",acS:"#1C1638",ok:"#4ADE80",warn:"#FBBF24",err:"#F87171",bd:"rgba(155,114,240,0.12)",div:"rgba(155,114,240,0.06)",sw:"#9B72F0"},
  rose:{name:"Rose",emoji:"🌸",bg:"#130810",bgEl:"#1A0E16",card:"#1E1018",cardHi:"#2A1520",glass:"rgba(30,16,24,0.88)",fg:"#FFD8E8",fg2:"#C07890",fg3:"#804058",ac:"#F064A8",acM:"#C04488",acS:"#30101E",ok:"#4ADE80",warn:"#FBBF24",err:"#F87171",bd:"rgba(240,100,168,0.12)",div:"rgba(240,100,168,0.06)",sw:"#F064A8"},
  ocean:{name:"Ocean",emoji:"🌊",bg:"#060C16",bgEl:"#0A1420",card:"#0C1828",cardHi:"#101E32",glass:"rgba(12,24,40,0.88)",fg:"#CCE4F8",fg2:"#4E84B0",fg3:"#2A4E78",ac:"#38A8F0",acM:"#1E78CC",acS:"#0A1E38",ok:"#4ADE80",warn:"#FBBF24",err:"#F87171",bd:"rgba(56,168,240,0.12)",div:"rgba(56,168,240,0.06)",sw:"#38A8F0"},
  sand:{name:"Sand",emoji:"✨",bg:"#110E08",bgEl:"#181408",card:"#1C180C",cardHi:"#241E0E",glass:"rgba(28,24,12,0.88)",fg:"#F2E8D0",fg2:"#A09060",fg3:"#685E3C",ac:"#E8BC60",acM:"#C09040",acS:"#2E2408",ok:"#4ADE80",warn:"#FBBF24",err:"#F87171",bd:"rgba(232,188,96,0.12)",div:"rgba(232,188,96,0.06)",sw:"#E8BC60"},
};

// ─── Data Types ───────────────────────────────────────────────────────────────

interface JEntry { id:number; title:string; mood:string; reflection:string; date:string; sticker:string; ts:number; }
interface RItem  { id:number; label:string; time:string; cat:string; icon:string; days:number[]; active:boolean; ts:number; }
interface WItem  { id:number; title:string; desc:string; notes:string; tag:string; emoji:string; cat:"saveForLater"|"urgentNeed"|"dreamCart"; ts:number; }
interface HLog   { id:number; amount:number; timeLabel:string; ts:number; }

type Snack = { msg:string; undo?:()=>void } | null;
type Confirm = { title:string; body:string; onOk:()=>void } | null;

// ─── Initial Data ─────────────────────────────────────────────────────────────

const INIT_J: JEntry[] = [
  {id:1,title:"A gentle morning",mood:"😌",reflection:"Started the day with tea and stretching. Felt present and at ease with everything around me.",date:"Jun 28",sticker:"🌸",ts:1751068800000},
  {id:2,title:"Processing feelings",mood:"😔",reflection:"Today was heavy but I made it through. Small wins count. I am proud of myself for showing up.",date:"Jun 26",sticker:"🌧️",ts:1750896000000},
  {id:3,title:"So grateful today",mood:"🥰",reflection:"Called mom. Had a long walk. Cooked something nourishing. These simple things matter.",date:"Jun 24",sticker:"✨",ts:1750723200000},
];

const INIT_R: RItem[] = [
  {id:1,label:"Evening supplements",time:"8:00 PM",cat:"Medication",icon:"💊",days:[0,1,2,3,4,5,6],active:true,ts:1},
  {id:2,label:"Drink water",time:"Every 2 hrs",cat:"Water",icon:"💧",days:[0,1,2,3,4],active:true,ts:2},
  {id:3,label:"Vitamin D & Iron",time:"9:00 AM",cat:"Medication",icon:"☀️",days:[0,2,4],active:false,ts:3},
  {id:4,label:"Evening face massage",time:"10:00 PM",cat:"Skincare",icon:"✨",days:[5,6],active:true,ts:4},
];

const INIT_W: WItem[] = [
  {id:1,title:"Silk pillowcase",desc:"25 momme mulberry silk, champagne",notes:"For hair care routine",tag:"Self-care",emoji:"🛁",cat:"saveForLater",ts:1},
  {id:2,title:"Liforme yoga mat",desc:"Natural rubber, eco-friendly, alignment",notes:"Measure space first",tag:"Wellness",emoji:"🧘",cat:"saveForLater",ts:2},
  {id:3,title:"Evening primrose oil",desc:"1000mg, 120 capsules, GLA-rich",notes:"Almost out",tag:"Supplements",emoji:"💊",cat:"urgentNeed",ts:3},
  {id:4,title:"Dyson Airwrap",desc:"Multi-styler, fine to medium hair",notes:"Wait for sale",tag:"Beauty",emoji:"💇",cat:"dreamCart",ts:4},
  {id:5,title:"Weighted blanket",desc:"15 lbs cooling bamboo, slate gray",notes:"For deeper sleep",tag:"Sleep",emoji:"🛏️",cat:"dreamCart",ts:5},
];

const INIT_H: HLog[] = [
  {id:1,amount:250,timeLabel:"8:30 AM",ts:Date.now()-7200000},
  {id:2,amount:250,timeLabel:"10:15 AM",ts:Date.now()-5400000},
  {id:3,amount:100,timeLabel:"12:00 PM",ts:Date.now()-3600000},
];

const MOODS = ["😊","😌","😐","😔","😤","🥰","😴","😰"];
const MOOD_LABELS: Record<string,string> = {"😊":"Happy","😌":"Calm","😐":"Neutral","😔":"Sad","😤":"Frustrated","🥰":"Loved","😴":"Tired","😰":"Anxious"};
const SYMPTOMS = ["Cramps","Bloating","Acne","Fatigue","Headache","Mood Swings","Sugar Cravings","Hair Thinning","Hirsutism","Sleep Issues","Skin Darkening"];
const FLOW_TYPES = ["Light","Medium","Heavy"];
const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];
const WEEK_W = [{day:"M",ml:1800},{day:"T",ml:2100},{day:"W",ml:1400},{day:"T",ml:2000},{day:"F",ml:1600},{day:"S",ml:2200},{day:"S",ml:600}];
const CYC_H = [{cycle:"Mar",length:29},{cycle:"Apr",length:27},{cycle:"May",length:31},{cycle:"Jun",length:28}];

// ─── Snackbar ──────────────────────────────────────────────────────────────────

function Snackbar({ snack, dismiss, t }: { snack:Snack; dismiss:()=>void; t:T }) {
  const timer = useRef<ReturnType<typeof setTimeout>|null>(null);
  useEffect(() => {
    if (!snack) return;
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(dismiss, 4500);
    return () => { if (timer.current) clearTimeout(timer.current); };
  }, [snack]);

  return (
    <AnimatePresence>
      {snack && (
        <motion.div
          key="snack"
          initial={{ y:80, opacity:0 }}
          animate={{ y:0, opacity:1 }}
          exit={{ y:80, opacity:0 }}
          transition={{ type:"spring", damping:28, stiffness:320 }}
          className="fixed z-[80] flex items-center gap-3 px-4 py-3 rounded-[16px]"
          style={{ bottom:90, left:"50%", transform:"translateX(-50%)", width:"calc(100% - 32px)", maxWidth:398,
            background:t.cardHi, border:`1px solid ${t.bd}`, boxShadow:"0 12px 40px rgba(0,0,0,0.5)" }}
        >
          <span className="flex-1 text-sm font-medium" style={{ color:t.fg }}>{snack.msg}</span>
          {snack.undo && (
            <button onClick={() => { snack.undo!(); dismiss(); }}
              className="text-sm font-bold px-2" style={{ color:t.ac }}>Undo</button>
          )}
          <button onClick={dismiss}><X size={14} color={t.fg2} /></button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ─── Confirm Dialog ────────────────────────────────────────────────────────────

function ConfirmDlg({ confirm, dismiss, t }: { confirm:Confirm; dismiss:()=>void; t:T }) {
  return (
    <AnimatePresence>
      {confirm && (
        <motion.div key="cdlg" className="fixed inset-0 z-[90] flex items-center justify-center"
          initial={{ opacity:0 }} animate={{ opacity:1 }} exit={{ opacity:0 }}>
          <motion.div className="absolute inset-0" style={{ background:"rgba(0,0,0,0.72)", backdropFilter:"blur(6px)" }}
            onClick={dismiss} />
          <motion.div className="relative mx-4 w-full max-w-[320px] p-6 rounded-[24px]"
            style={{ background:t.cardHi, border:`1px solid ${t.bd}` }}
            initial={{ scale:0.88, opacity:0, y:12 }} animate={{ scale:1, opacity:1, y:0 }} exit={{ scale:0.88, opacity:0 }}
            transition={{ type:"spring", damping:26, stiffness:340 }}>
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-4 mx-auto" style={{ background:"#F8717120" }}>
              <AlertTriangle size={22} color={t.err} />
            </div>
            <h3 className="text-base font-bold text-center mb-2" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>{confirm.title}</h3>
            <p className="text-sm text-center mb-6 leading-relaxed" style={{ color:t.fg2 }}>{confirm.body}</p>
            <div className="flex gap-3">
              <button onClick={dismiss} className="flex-1 py-3 rounded-[14px] text-sm font-bold" style={{ background:t.acS, color:t.fg2 }}>Cancel</button>
              <button onClick={() => { confirm.onOk(); dismiss(); }}
                className="flex-1 py-3 rounded-[14px] text-sm font-bold" style={{ background:t.err, color:"#fff" }}>Delete</button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ─── Bottom Sheet ──────────────────────────────────────────────────────────────

function Sheet({ open, onClose, title, children, t }: {
  open:boolean; onClose:()=>void; title:string; children:React.ReactNode; t:T;
}) {
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div key="sbd" className="fixed inset-0 z-[55]"
            style={{ background:"rgba(0,0,0,0.65)", backdropFilter:"blur(4px)" }}
            initial={{ opacity:0 }} animate={{ opacity:1 }} exit={{ opacity:0 }}
            onClick={onClose} />
          <motion.div key="sht" className="fixed bottom-0 z-[60] w-full max-w-[430px] rounded-t-[28px] overflow-hidden"
            style={{ left:"50%", transform:"translateX(-50%)", background:t.cardHi }}
            initial={{ y:"100%" }} animate={{ y:0 }} exit={{ y:"100%" }}
            transition={{ type:"spring", damping:32, stiffness:320 }}>
            <div className="flex justify-center pt-3 pb-0">
              <div className="w-10 h-1 rounded-full" style={{ background:t.fg3 }} />
            </div>
            <div className="flex items-center justify-between px-5 pt-3 pb-2">
              <h3 className="text-base font-bold" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>{title}</h3>
              <button onClick={onClose} className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background:t.acS }}>
                <X size={15} color={t.fg2} />
              </button>
            </div>
            <div className="overflow-y-auto hs" style={{ maxHeight:"78vh" }}>
              {children}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

// ─── Swipe-to-Delete Row ───────────────────────────────────────────────────────

function SwipeRow({ children, onDelete, t }: { children:React.ReactNode; onDelete:()=>void; t:T }) {
  const x = useMotionValue(0);
  const bg = useTransform(x, [-80, 0], [t.err, t.card]);
  const iconOp = useTransform(x, [-80, -20], [1, 0]);

  return (
    <div className="relative overflow-hidden rounded-[22px]">
      <div className="absolute inset-y-0 right-0 w-20 flex items-center justify-center rounded-r-[22px]" style={{ background:t.err }}>
        <motion.div style={{ opacity:iconOp }}><Trash2 size={18} color="#fff" /></motion.div>
      </div>
      <motion.div drag="x" dragConstraints={{ left:-80, right:0 }} dragElastic={0.06}
        style={{ x, background:t.card, position:"relative", zIndex:1 }}
        onDragEnd={(_, i) => { if (i.offset.x < -50 || i.velocity.x < -400) onDelete(); }}>
        {children}
      </motion.div>
    </div>
  );
}

// ─── Primitives ───────────────────────────────────────────────────────────────

function Chip({ label, selected, onClick, t }: { label:string; selected:boolean; onClick:()=>void; t:T }) {
  return (
    <motion.button whileTap={{ scale:0.9 }} onClick={onClick}
      className="px-3 py-1.5 rounded-full text-xs font-semibold shrink-0 transition-colors"
      style={{ background:selected?t.ac:t.acS, color:selected?"#000":t.fg2, border:`1px solid ${selected?t.ac:t.bd}` }}>
      {label}
    </motion.button>
  );
}

function Toggle({ active, onChange, t }: { active:boolean; onChange:()=>void; t:T }) {
  return (
    <button onClick={onChange} className="relative shrink-0 transition-colors duration-300"
      style={{ width:44, height:24, borderRadius:12, background:active?t.ac:t.acS }}>
      <motion.div layout transition={{ type:"spring", stiffness:520, damping:32 }}
        className="absolute top-[3px] w-[18px] h-[18px] rounded-full bg-white shadow"
        style={{ left:active?"calc(100% - 21px)":3 }} />
    </button>
  );
}

function PrimaryBtn({ label, onClick, t, icon, full=true }: {
  label:string; onClick?:()=>void; t:T; icon?:React.ReactNode; full?:boolean;
}) {
  return (
    <motion.button whileTap={{ scale:0.96 }} onClick={onClick}
      className={`${full?"w-full":""} py-3.5 rounded-[16px] text-sm font-bold flex items-center justify-center gap-2`}
      style={{ background:t.ac, color:"#000" }}>
      {icon}{label}
    </motion.button>
  );
}

function MLabel({ text, t }: { text:string; t:T }) {
  return <p className="text-[10px] font-bold tracking-[0.12em] uppercase mb-2" style={{ color:t.fg2, fontFamily:"'DM Mono',monospace" }}>{text}</p>;
}

function SHead({ title, action, t }: { title:string; action?:string; t:T }) {
  return (
    <div className="flex items-center justify-between mb-4">
      <MLabel text={title} t={t} />
      {action && <button className="text-xs font-bold" style={{ color:t.ac }}>{action}</button>}
    </div>
  );
}

// ─── Water Ball ────────────────────────────────────────────────────────────────

function WaterBall({ pct, color }: { pct:number; color:string }) {
  const fy = 128 - (128 * pct / 100);
  return (
    <div style={{ width:152, height:152, margin:"0 auto" }}>
      <svg width="152" height="152" viewBox="0 0 152 152">
        <defs>
          <clipPath id="wc"><circle cx="76" cy="76" r="64" /></clipPath>
          <linearGradient id="wg" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={color} stopOpacity="0.9" />
            <stop offset="100%" stopColor={color} stopOpacity="0.5" />
          </linearGradient>
        </defs>
        <circle cx="76" cy="76" r="72" fill="none" stroke={color} strokeWidth="1" strokeOpacity="0.15" />
        <circle cx="76" cy="76" r="64" fill="rgba(255,255,255,0.025)" />
        <g clipPath="url(#wc)">
          <rect x="0" y={fy+8} width="152" height={152-fy} fill="url(#wg)" />
          <g style={{ animation:"waveMove 2.8s linear infinite" }}>
            <path d={`M-152,${fy+10} C-114,${fy} -76,${fy+18} -38,${fy+10} C0,${fy} 38,${fy+18} 76,${fy+10} C114,${fy} 152,${fy+18} 190,${fy+10} C228,${fy} 266,${fy+18} 304,${fy+10} L304,152 L-152,152 Z`} fill={color} opacity="0.8" />
          </g>
        </g>
        <text x="76" y="71" textAnchor="middle" fill="white" fontSize="22" fontWeight="800" fontFamily="'Plus Jakarta Sans',sans-serif">{pct}%</text>
        <text x="76" y="87" textAnchor="middle" fill="rgba(255,255,255,0.55)" fontSize="9" fontFamily="'DM Sans',sans-serif">of daily goal</text>
      </svg>
    </div>
  );
}

// ─── Calendar ─────────────────────────────────────────────────────────────────

function Cal({ t, periodDays, selDay, onSel }: { t:T; periodDays:number[]; selDay:number; onSel:(d:number)=>void }) {
  const [month, setMonth] = useState(5);
  const year = 2026;
  const dim = new Date(year, month+1, 0).getDate();
  const fd = new Date(year, month, 1).getDay();
  return (
    <div className="rounded-[22px] p-4" style={{ background:t.card, border:`1px solid ${t.bd}` }}>
      <div className="flex items-center justify-between mb-4">
        <motion.button whileTap={{ scale:0.85 }} onClick={() => setMonth(m => Math.max(0,m-1))}
          className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background:t.acS }}>
          <ChevronLeft size={15} color={t.fg2} />
        </motion.button>
        <span className="text-sm font-bold" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>{MONTHS[month]} {year}</span>
        <motion.button whileTap={{ scale:0.85 }} onClick={() => setMonth(m => Math.min(11,m+1))}
          className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background:t.acS }}>
          <ChevronRight size={15} color={t.fg2} />
        </motion.button>
      </div>
      <div className="grid grid-cols-7 mb-1">
        {["S","M","T","W","T","F","S"].map((d,i) => (
          <div key={i} className="text-center text-[10px] font-bold py-1" style={{ color:t.fg3, fontFamily:"'DM Mono',monospace" }}>{d}</div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-y-0.5">
        {Array.from({length:fd}).map((_,i) => <div key={`e${i}`} />)}
        {Array.from({length:dim},(_,i)=>i+1).map(day => {
          const iP=periodDays.includes(day), iS=selDay===day;
          return (
            <motion.button key={day} whileTap={{ scale:0.8 }} onClick={() => onSel(day)}
              className="w-8 h-8 mx-auto rounded-full flex items-center justify-center text-[11px] font-semibold"
              style={{ background:iS?t.ac:iP?`${t.ac}22`:"transparent", color:iS?"#000":iP?t.ac:t.fg }}>
              {day}
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}

// ─── StatusBar + BottomNav ────────────────────────────────────────────────────

function StatusBar({ t }: { t:T }) {
  return (
    <div className="flex items-center justify-between px-5 pt-3 pb-1">
      <span className="text-[11px] font-bold" style={{ color:t.fg, fontFamily:"'DM Mono',monospace" }}>9:41</span>
      <div className="flex items-center gap-2.5">
        <div className="flex gap-[2px] items-end h-3">
          {[3,5,7,10].map((h,i) => <div key={i} style={{ width:3, height:h, background:i<3?t.fg:`${t.fg}25`, borderRadius:1 }} />)}
        </div>
        <svg width="14" height="10" viewBox="0 0 14 10" fill="none">
          <circle cx="7" cy="9" r="1.2" fill={t.fg} />
          <path d="M4 6.5 Q7 4.2 10 6.5" stroke={t.fg} strokeWidth="1.4" strokeLinecap="round" />
          <path d="M1.5 3.8 Q7 0.2 12.5 3.8" stroke={t.fg} strokeWidth="1.2" strokeLinecap="round" opacity="0.45" />
        </svg>
        <div className="flex items-center gap-0.5">
          <div style={{ width:22, height:11, borderRadius:3, border:`1.2px solid ${t.fg}60`, position:"relative" }}>
            <div style={{ position:"absolute", top:2, left:2, bottom:2, borderRadius:1.5, background:t.fg, width:"70%" }} />
          </div>
          <div style={{ width:2, height:5, borderRadius:"0 1px 1px 0", background:`${t.fg}40` }} />
        </div>
      </div>
    </div>
  );
}

function BNav({ active, onChange, t }: { active:string; onChange:(s:string)=>void; t:T }) {
  const tabs=[{key:"home",icon:Home,label:"Home"},{key:"cycle",icon:Flower2,label:"Cycle"},{key:"journal",icon:BookOpen,label:"Journal"},{key:"water",icon:Droplets,label:"Water"},{key:"settings",icon:Settings,label:"Settings"}];
  return (
    <div className="absolute bottom-0 left-0 right-0 px-3 pb-5 pt-3 z-50"
      style={{ background:`linear-gradient(to top,${t.bg} 55%,transparent)` }}>
      <div className="flex items-center justify-around p-2 rounded-[28px]"
        style={{ background:t.glass, backdropFilter:"blur(24px)", border:`1px solid ${t.bd}`, boxShadow:`0 16px 48px rgba(0,0,0,0.5)` }}>
        {tabs.map(({ key,icon:Icon,label }) => {
          const on = active===key;
          return (
            <motion.button key={key} whileTap={{ scale:0.82 }} onClick={() => onChange(key)}
              className="flex flex-col items-center gap-1 py-1.5 px-3 rounded-[18px] transition-all duration-200"
              style={{ background:on?`${t.ac}15`:"transparent" }}>
              <Icon size={20} color={on?t.ac:t.fg3} strokeWidth={on?2.2:1.6} />
              <span className="text-[9px] font-bold" style={{ color:on?t.ac:t.fg3 }}>{label}</span>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}

// ─── Empty State ──────────────────────────────────────────────────────────────

function Empty({ icon, title, body, action, onAction, t }: {
  icon:string; title:string; body:string; action?:string; onAction?:()=>void; t:T;
}) {
  return (
    <div className="py-16 flex flex-col items-center gap-3 px-8 text-center">
      <span className="text-5xl" style={{ animation:"float 3s ease-in-out infinite" }}>{icon}</span>
      <p className="text-sm font-bold" style={{ color:t.fg2, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>{title}</p>
      <p className="text-xs leading-relaxed" style={{ color:t.fg3 }}>{body}</p>
      {action && onAction && (
        <motion.button whileTap={{ scale:0.94 }} onClick={onAction}
          className="mt-2 px-5 py-2.5 rounded-full text-xs font-bold" style={{ background:t.ac, color:"#000" }}>
          {action}
        </motion.button>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// DASHBOARD
// ═══════════════════════════════════════════════════════════════════════════════

function Dashboard({ t, waterAmount, mood, jEntries, setTab }: {
  t:T; waterAmount:number; mood:string; jEntries:JEntry[]; setTab:(s:string)=>void;
}) {
  const hydPct = Math.round((waterAmount/2000)*100);
  const qa=[
    {icon:Droplets,label:"Log Water",tab:"water",color:"#38A8F0"},
    {icon:Smile,label:"Log Mood",tab:"journal",color:"#FBBF24"},
    {icon:Flower2,label:"Cycle",tab:"cycle",color:"#F064A8"},
    {icon:Bell,label:"Reminders",tab:"settings",color:"#9B72F0"},
  ];

  return (
    <div className="pb-32 px-4 pt-2 space-y-5">
      {/* Hero */}
      <motion.div initial={{ opacity:0, y:14 }} animate={{ opacity:1, y:0 }} transition={{ duration:0.38 }} className="pt-3 pb-1">
        <p className="text-[10px] font-semibold tracking-[0.15em] uppercase mb-2" style={{ color:t.fg3, fontFamily:"'DM Mono',monospace" }}>Tuesday · July 1, 2026</p>
        <h1 className="text-[26px] font-extrabold leading-tight mb-1.5" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif", letterSpacing:"-0.02em" }}>
          ✨ Abantika
        </h1>
        <p className="text-sm" style={{ color:t.fg2 }}>Take care of yourself today.</p>
      </motion.div>

      {/* Quick actions */}
      <div className="grid grid-cols-4 gap-2">
        {qa.map(({ icon:Icon, label, tab, color }, i) => (
          <motion.button key={label} whileTap={{ scale:0.88 }} onClick={() => setTab(tab)}
            initial={{ opacity:0, y:10 }} animate={{ opacity:1, y:0 }} transition={{ delay:i*0.06 }}
            className="flex flex-col items-center gap-2 p-3 rounded-[18px]"
            style={{ background:t.card, border:`1px solid ${t.bd}` }}>
            <div className="w-10 h-10 rounded-2xl flex items-center justify-center" style={{ background:`${color}18` }}>
              <Icon size={17} color={color} />
            </div>
            <span className="text-[9px] font-semibold text-center leading-tight" style={{ color:t.fg2 }}>{label}</span>
          </motion.button>
        ))}
      </div>

      {/* Hydration bar */}
      <motion.button whileTap={{ scale:0.98 }} onClick={() => setTab("water")}
        className="w-full text-left rounded-[24px] p-4" style={{ background:t.card, border:`1px solid ${t.bd}` }}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl flex items-center justify-center" style={{ background:"#38A8F018" }}>
              <Droplets size={13} color="#38A8F0" />
            </div>
            <span className="text-[10px] font-bold tracking-widest uppercase" style={{ color:t.fg2, fontFamily:"'DM Mono',monospace" }}>Hydration</span>
          </div>
          <span className="text-[10px] font-bold" style={{ color:"#38A8F0" }}>{hydPct}%</span>
        </div>
        <div className="relative h-2 rounded-full overflow-hidden mb-3" style={{ background:t.acS }}>
          <motion.div initial={{ width:0 }} animate={{ width:`${hydPct}%` }} transition={{ duration:1, ease:"easeOut", delay:0.3 }}
            className="h-full rounded-full" style={{ background:"linear-gradient(90deg,#38A8F0,#60C8FF)" }} />
        </div>
        <div className="flex items-baseline gap-1">
          <span className="text-2xl font-extrabold" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>{waterAmount}</span>
          <span className="text-xs" style={{ color:t.fg2 }}>/ 2000 ml today</span>
        </div>
      </motion.button>

      {/* Mood + Cycle */}
      <div className="grid grid-cols-2 gap-3">
        <motion.button whileTap={{ scale:0.96 }} onClick={() => setTab("journal")}
          className="p-4 rounded-[22px] text-left" style={{ background:t.card, border:`1px solid ${t.bd}` }}>
          <div className="flex items-center gap-1.5 mb-3">
            <Smile size={11} color="#FBBF24" />
            <span className="text-[9px] font-bold tracking-widest uppercase" style={{ color:t.fg2, fontFamily:"'DM Mono',monospace" }}>Mood</span>
          </div>
          <div className="text-4xl mb-1.5" style={{ display:"inline-block", animation:"float 3s ease-in-out infinite" }}>{mood}</div>
          <div className="text-sm font-bold block" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>{MOOD_LABELS[mood]}</div>
          <div className="text-[10px] mt-0.5" style={{ color:t.fg2 }}>Today</div>
        </motion.button>

        <motion.button whileTap={{ scale:0.96 }} onClick={() => setTab("cycle")}
          className="p-4 rounded-[22px] text-left" style={{ background:t.card, border:`1px solid ${t.bd}` }}>
          <div className="flex items-center gap-1.5 mb-3">
            <Flower2 size={11} color="#F064A8" />
            <span className="text-[9px] font-bold tracking-widest uppercase" style={{ color:t.fg2, fontFamily:"'DM Mono',monospace" }}>Cycle</span>
          </div>
          <div className="text-2xl font-extrabold mb-1" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>18</div>
          <div className="text-[9px] px-2 py-0.5 rounded-full inline-block mb-1" style={{ background:"#F064A818", color:"#F064A8" }}>Follicular</div>
          <div className="text-[10px] block" style={{ color:t.fg2 }}>~10 days away</div>
        </motion.button>
      </div>

      {/* Streak + Reminder */}
      <div className="grid grid-cols-2 gap-3">
        <div className="p-4 rounded-[22px]" style={{ background:t.card, border:`1px solid ${t.bd}` }}>
          <div className="flex items-center gap-1.5 mb-3">
            <Zap size={11} color={t.warn} />
            <span className="text-[9px] font-bold tracking-widest uppercase" style={{ color:t.fg2, fontFamily:"'DM Mono',monospace" }}>Streak</span>
          </div>
          <div className="text-2xl font-extrabold mb-0.5" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>12 🔥</div>
          <div className="text-[10px]" style={{ color:t.fg2 }}>days consistent</div>
        </div>

        <motion.button whileTap={{ scale:0.96 }} onClick={() => setTab("settings")}
          className="p-4 rounded-[22px] text-left" style={{ background:t.card, border:`1px solid ${t.bd}` }}>
          <div className="flex items-center gap-1.5 mb-3">
            <Bell size={11} color="#9B72F0" />
            <span className="text-[9px] font-bold tracking-widest uppercase" style={{ color:t.fg2, fontFamily:"'DM Mono',monospace" }}>Next</span>
          </div>
          <div className="text-sm font-bold mb-1" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>Supplements</div>
          <div className="text-[9px] px-2 py-0.5 rounded-full inline-block" style={{ background:"#9B72F018", color:"#9B72F0" }}>8:00 PM</div>
        </motion.button>
      </div>

      {/* Encouragement */}
      <div className="rounded-[24px] overflow-hidden" style={{ background:t.card, border:`1px solid ${t.bd}` }}>
        <div className="h-28 relative flex items-center justify-center overflow-hidden"
          style={{ background:`linear-gradient(145deg,${t.acS} 0%,${t.cardHi} 100%)` }}>
          <svg viewBox="0 0 360 112" className="absolute inset-0 w-full h-full" preserveAspectRatio="xMidYMid slice">
            <defs>
              <radialGradient id="db1" cx="25%" cy="50%" r="50%"><stop offset="0%" stopColor={t.ac} stopOpacity="0.14" /><stop offset="100%" stopColor={t.ac} stopOpacity="0" /></radialGradient>
              <radialGradient id="db2" cx="78%" cy="50%" r="40%"><stop offset="0%" stopColor={t.ac} stopOpacity="0.09" /><stop offset="100%" stopColor={t.ac} stopOpacity="0" /></radialGradient>
            </defs>
            <ellipse cx="90" cy="56" rx="140" ry="90" fill="url(#db1)" />
            <ellipse cx="280" cy="56" rx="120" ry="80" fill="url(#db2)" />
          </svg>
          <span className="text-5xl relative z-10" style={{ animation:"float 4s ease-in-out infinite" }}>🌷</span>
        </div>
        <div className="p-4">
          <div className="flex items-center gap-1.5 mb-2">
            <Star size={11} color={t.ac} fill={t.ac} />
            <span className="text-[9px] font-bold tracking-[0.14em] uppercase" style={{ color:t.fg2, fontFamily:"'DM Mono',monospace" }}>Daily Reflection</span>
          </div>
          <p className="text-sm font-semibold leading-relaxed mb-2" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>
            "You are doing better than you think. Rest is not laziness — it is how you replenish yourself."
          </p>
          <p className="text-xs leading-relaxed" style={{ color:t.fg2 }}>
            Your body works hard every day. A few moments of stillness can restore more than you expect.
          </p>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// JOURNAL
// ═══════════════════════════════════════════════════════════════════════════════

function JournalScreen({ t, journal, setJournal, wishlist, setWishlist, mood, setMood, showSnack, showConfirm }: {
  t:T; journal:JEntry[]; setJournal:React.Dispatch<React.SetStateAction<JEntry[]>>;
  wishlist:WItem[]; setWishlist:React.Dispatch<React.SetStateAction<WItem[]>>;
  mood:string; setMood:(m:string)=>void;
  showSnack:(msg:string,undo?:()=>void)=>void;
  showConfirm:(title:string,body:string,onOk:()=>void)=>void;
}) {
  const [tab, setTab] = useState<"diary"|"wishlist">("diary");
  const [wTab, setWTab] = useState<"saveForLater"|"urgentNeed"|"dreamCart">("saveForLater");
  const [search, setSearch] = useState("");
  const [moodFilter, setMoodFilter] = useState<string|null>(null);
  const [sort, setSort] = useState<"newest"|"oldest">("newest");
  const [showSort, setShowSort] = useState(false);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [editEntry, setEditEntry] = useState<JEntry|null>(null);
  const [wSheetOpen, setWSheetOpen] = useState(false);

  // Form state
  const [fTitle, setFTitle] = useState("");
  const [fMood, setFMood] = useState("😊");
  const [fReflection, setFReflection] = useState("");
  const [fSticker, setFSticker] = useState("✨");
  const stickers = ["✨","🌸","🌧️","🔥","🌙","🦋","🌻","💫"];

  const openCreate = () => { setEditEntry(null); setFTitle(""); setFMood("😊"); setFReflection(""); setFSticker("✨"); setSheetOpen(true); };
  const openEdit = (e:JEntry) => { setEditEntry(e); setFTitle(e.title); setFMood(e.mood); setFReflection(e.reflection); setFSticker(e.sticker); setSheetOpen(true); };

  const saveEntry = () => {
    if (!fTitle.trim()) return;
    const now = Date.now();
    if (editEntry) {
      setJournal(p => p.map(e => e.id===editEntry.id ? { ...e, title:fTitle, mood:fMood, reflection:fReflection, sticker:fSticker } : e));
      showSnack("Entry updated");
    } else {
      const d = new Date();
      const newE: JEntry = { id:now, title:fTitle, mood:fMood, reflection:fReflection, sticker:fSticker, date:`${["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][d.getMonth()]} ${d.getDate()}`, ts:now };
      setJournal(p => [newE, ...p]);
      showSnack("Entry saved ✨");
    }
    setSheetOpen(false);
  };

  const deleteEntry = (id:number) => {
    const entry = journal.find(e => e.id===id)!;
    showConfirm("Delete entry?","This entry will be permanently removed.", () => {
      setJournal(p => p.filter(e => e.id!==id));
      showSnack("Entry deleted", () => setJournal(p => [entry, ...p].sort((a,b) => b.ts-a.ts)));
    });
  };

  // Wishlist CRUD
  const [wFTitle, setWFTitle] = useState("");
  const [wFDesc, setWFDesc] = useState("");
  const [wFNotes, setWFNotes] = useState("");
  const [wFTag, setWFTag] = useState("");
  const [wFEmoji, setWFEmoji] = useState("✨");

  const saveWishItem = () => {
    if (!wFTitle.trim()) return;
    const now = Date.now();
    setWishlist(p => [{ id:now, title:wFTitle, desc:wFDesc, notes:wFNotes, tag:wFTag||"Other", emoji:wFEmoji, cat:wTab, ts:now }, ...p]);
    setWSheetOpen(false);
    setWFTitle(""); setWFDesc(""); setWFNotes(""); setWFTag(""); setWFEmoji("✨");
    showSnack("Added to wishlist 🛍️");
  };

  const deleteWishItem = (id:number) => {
    const item = wishlist.find(w => w.id===id)!;
    setWishlist(p => p.filter(w => w.id!==id));
    showSnack("Item removed", () => setWishlist(p => [item, ...p].sort((a,b) => a.ts-b.ts)));
  };

  const entries = journal
    .filter(e => !moodFilter || e.mood===moodFilter)
    .filter(e => !search || e.title.toLowerCase().includes(search.toLowerCase()) || e.reflection.toLowerCase().includes(search.toLowerCase()))
    .sort((a,b) => sort==="newest" ? b.ts-a.ts : a.ts-b.ts);

  const wItems = wishlist.filter(w => w.cat===wTab);

  return (
    <>
      <div className="pb-32 px-4 pt-4 space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-extrabold" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif", letterSpacing:"-0.02em" }}>Journal</h1>
        </div>

        {/* Tab bar */}
        <div className="flex gap-1 p-1 rounded-[16px]" style={{ background:t.card }}>
          {[{k:"diary",l:"📔 My Diary"},{k:"wishlist",l:"🛍️ Wishlist"}].map(({ k,l }) => (
            <button key={k} onClick={() => setTab(k as "diary"|"wishlist")}
              className="flex-1 py-2 rounded-[12px] text-xs font-bold transition-all"
              style={{ background:tab===k?t.ac:"transparent", color:tab===k?"#000":t.fg2 }}>
              {l}
            </button>
          ))}
        </div>

        {tab==="diary" ? (
          <>
            {/* Search + Sort */}
            <div className="flex gap-2">
              <div className="flex-1 flex items-center gap-2 px-3 py-2.5 rounded-[14px]" style={{ background:t.card, border:`1px solid ${t.bd}` }}>
                <Search size={13} color={t.fg2} />
                <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search entries…"
                  className="flex-1 bg-transparent text-xs outline-none" style={{ color:t.fg }} />
                {search && <button onClick={() => setSearch("")}><X size={12} color={t.fg2} /></button>}
              </div>
              <motion.button whileTap={{ scale:0.9 }} onClick={() => setShowSort(!showSort)}
                className="w-10 h-10 rounded-[14px] flex items-center justify-center"
                style={{ background:t.card, border:`1px solid ${t.bd}` }}>
                <ArrowUpDown size={14} color={t.fg2} />
              </motion.button>
            </div>

            {/* Sort sheet */}
            <AnimatePresence>
              {showSort && (
                <motion.div initial={{ opacity:0, y:-6 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0, y:-6 }}
                  className="rounded-[14px] overflow-hidden" style={{ background:t.cardHi, border:`1px solid ${t.bd}` }}>
                  {[{k:"newest",l:"Newest first"},{k:"oldest",l:"Oldest first"}].map(({ k,l }) => (
                    <button key={k} onClick={() => { setSort(k as "newest"|"oldest"); setShowSort(false); }}
                      className="w-full flex items-center justify-between px-4 py-3 text-sm font-medium"
                      style={{ color:sort===k?t.ac:t.fg, borderBottom:k==="newest"?`1px solid ${t.div}`:"none" }}>
                      {l}
                      {sort===k && <Check size={14} color={t.ac} />}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Mood filter */}
            <div className="flex gap-2 overflow-x-auto -mx-1 px-1 pb-0.5 hs">
              <button onClick={() => setMoodFilter(null)}
                className="px-3 py-1.5 rounded-full text-[10px] font-bold shrink-0"
                style={{ background:!moodFilter?t.ac:t.acS, color:!moodFilter?"#000":t.fg2 }}>All</button>
              {MOODS.map(m => (
                <motion.button key={m} whileTap={{ scale:0.85 }} onClick={() => setMoodFilter(moodFilter===m?null:m)}
                  className="w-8 h-8 rounded-full text-base flex items-center justify-center shrink-0"
                  style={{ background:moodFilter===m?t.ac:t.acS, border:`1px solid ${moodFilter===m?t.ac:t.bd}` }}>
                  {m}
                </motion.button>
              ))}
            </div>

            {/* Entries */}
            {entries.length === 0 ? (
              <Empty icon="📭" title="No entries yet" body="Your thoughts deserve a home. Start writing — every reflection is a step toward knowing yourself." action="Write today's entry" onAction={openCreate} t={t} />
            ) : (
              <div className="space-y-3">
                <AnimatePresence initial={false}>
                  {entries.map((entry, i) => (
                    <motion.div key={entry.id} layout
                      initial={{ opacity:0, y:10 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0, x:-60, height:0, marginBottom:0 }}
                      transition={{ duration:0.22, delay:i<5?i*0.04:0 }}>
                      <SwipeRow t={t} onDelete={() => deleteEntry(entry.id)}>
                        <div className="p-4">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-2.5">
                              <span className="text-2xl">{entry.sticker}</span>
                              <div>
                                <div className="text-sm font-bold" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>{entry.title}</div>
                                <div className="text-[10px]" style={{ color:t.fg3 }}>{entry.date}</div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-base">{entry.mood}</span>
                              <motion.button whileTap={{ scale:0.85 }} onClick={() => openEdit(entry)}
                                className="w-7 h-7 rounded-full flex items-center justify-center" style={{ background:t.acS }}>
                                <Pencil size={11} color={t.fg2} />
                              </motion.button>
                            </div>
                          </div>
                          <p className="text-xs leading-relaxed" style={{ color:t.fg2 }}>{entry.reflection}</p>
                        </div>
                      </SwipeRow>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </>
        ) : (
          <>
            {/* Wishlist category pills */}
            <div className="flex gap-2 overflow-x-auto -mx-1 px-1 pb-0.5 hs">
              {([{k:"saveForLater",l:"Save for Later",e:"🔖"},{k:"urgentNeed",l:"Urgent Need",e:"⚡"},{k:"dreamCart",l:"Dream Cart",e:"✨"}] as {k:"saveForLater"|"urgentNeed"|"dreamCart";l:string;e:string}[]).map(({ k,l,e }) => (
                <button key={k} onClick={() => setWTab(k)}
                  className="px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5 shrink-0"
                  style={{ background:wTab===k?t.ac:t.acS, color:wTab===k?"#000":t.fg2, border:`1px solid ${wTab===k?t.ac:t.bd}` }}>
                  {e} {l}
                </button>
              ))}
            </div>

            {wItems.length === 0 ? (
              <Empty icon="🛒" title="Nothing here yet" body="Add things that inspire you, that you need, or that you dream about." action="Add item" onAction={() => setWSheetOpen(true)} t={t} />
            ) : (
              <div className="space-y-3">
                <AnimatePresence initial={false}>
                  {wItems.map((item, i) => (
                    <motion.div key={item.id} layout
                      initial={{ opacity:0, y:10 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0, x:-60, height:0 }}
                      transition={{ duration:0.22, delay:i*0.05 }}>
                      <SwipeRow t={t} onDelete={() => deleteWishItem(item.id)}>
                        <div className="flex items-center gap-3 p-4">
                          <div className="w-12 h-12 rounded-[14px] flex items-center justify-center text-2xl shrink-0"
                            style={{ background:t.acS }}>{item.emoji}</div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-0.5">
                              <span className="text-sm font-bold truncate" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>{item.title}</span>
                              <span className="text-[9px] px-1.5 py-0.5 rounded-full shrink-0" style={{ background:`${t.ac}18`, color:t.ac }}>{item.tag}</span>
                            </div>
                            <p className="text-xs truncate" style={{ color:t.fg2 }}>{item.desc}</p>
                            {item.notes && <p className="text-[10px] mt-0.5 truncate" style={{ color:t.fg3 }}>📝 {item.notes}</p>}
                          </div>
                        </div>
                      </SwipeRow>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </>
        )}
      </div>

      {/* FAB */}
      <motion.button whileTap={{ scale:0.88 }}
        onClick={tab==="diary" ? openCreate : () => setWSheetOpen(true)}
        className="fixed z-40 w-14 h-14 rounded-full flex items-center justify-center shadow-2xl"
        style={{ bottom:100, right:20, background:t.ac, boxShadow:`0 8px 32px ${t.ac}60` }}>
        <Plus size={24} color="#000" />
      </motion.button>

      {/* Journal entry sheet */}
      <Sheet open={sheetOpen} onClose={() => setSheetOpen(false)} title={editEntry ? "Edit Entry" : "New Entry"} t={t}>
        <div className="px-5 pb-6 space-y-4">
          <div>
            <MLabel text="Title" t={t} />
            <input value={fTitle} onChange={e => setFTitle(e.target.value)} placeholder="What's on your mind?"
              className="w-full text-sm p-3 rounded-[12px] outline-none"
              style={{ background:t.acS, color:t.fg, border:`1px solid ${t.bd}`, fontFamily:"'Plus Jakarta Sans',sans-serif" }} />
          </div>

          <div>
            <MLabel text="Mood" t={t} />
            <div className="flex gap-2 flex-wrap">
              {MOODS.map(m => (
                <motion.button key={m} whileTap={{ scale:0.82 }} onClick={() => setFMood(m)}
                  className="w-10 h-10 rounded-full text-xl flex items-center justify-center"
                  style={{ background:fMood===m?t.ac:t.acS, border:`2px solid ${fMood===m?t.ac:t.bd}` }}>
                  {m}
                </motion.button>
              ))}
            </div>
          </div>

          <div>
            <MLabel text="Sticker" t={t} />
            <div className="flex gap-2 flex-wrap">
              {["✨","🌸","🌧️","🔥","🌙","🦋","🌻","💫"].map(s => (
                <motion.button key={s} whileTap={{ scale:0.82 }} onClick={() => setFSticker(s)}
                  className="w-10 h-10 rounded-full text-xl flex items-center justify-center"
                  style={{ background:fSticker===s?t.ac:t.acS, border:`2px solid ${fSticker===s?t.ac:t.bd}` }}>
                  {s}
                </motion.button>
              ))}
            </div>
          </div>

          <div>
            <MLabel text="Reflection" t={t} />
            <textarea value={fReflection} onChange={e => setFReflection(e.target.value)}
              placeholder="Write freely — this is only for you." rows={5}
              className="w-full text-xs p-3 rounded-[12px] resize-none outline-none leading-relaxed"
              style={{ background:t.acS, color:t.fg, border:`1px solid ${t.bd}`, fontFamily:"'DM Sans',sans-serif" }} />
          </div>

          <PrimaryBtn label={editEntry?"Update Entry":"Save Entry"} onClick={saveEntry} t={t} icon={<Check size={15} />} />
        </div>
      </Sheet>

      {/* Wishlist item sheet */}
      <Sheet open={wSheetOpen} onClose={() => setWSheetOpen(false)} title="Add to Wishlist" t={t}>
        <div className="px-5 pb-6 space-y-4">
          {[
            { label:"Item Name", val:wFTitle, set:setWFTitle, ph:"What do you want?" },
            { label:"Description", val:wFDesc, set:setWFDesc, ph:"Brand, size, details…" },
            { label:"Notes", val:wFNotes, set:setWFNotes, ph:"Why you want it, price range…" },
            { label:"Tag", val:wFTag, set:setWFTag, ph:"Self-care, Wellness, Beauty…" },
          ].map(({ label, val, set, ph }) => (
            <div key={label}>
              <MLabel text={label} t={t} />
              <input value={val} onChange={e => set(e.target.value)} placeholder={ph}
                className="w-full text-sm p-3 rounded-[12px] outline-none"
                style={{ background:t.acS, color:t.fg, border:`1px solid ${t.bd}`, fontFamily:"'DM Sans',sans-serif" }} />
            </div>
          ))}
          <div>
            <MLabel text="Emoji" t={t} />
            <div className="flex gap-2 flex-wrap">
              {["✨","🛁","🧘","💊","💇","🛏️","🌸","🎁","📦","💄"].map(e => (
                <motion.button key={e} whileTap={{ scale:0.82 }} onClick={() => setWFEmoji(e)}
                  className="w-10 h-10 rounded-full text-xl flex items-center justify-center"
                  style={{ background:wFEmoji===e?t.ac:t.acS, border:`2px solid ${wFEmoji===e?t.ac:t.bd}` }}>
                  {e}
                </motion.button>
              ))}
            </div>
          </div>
          <PrimaryBtn label="Add to Wishlist" onClick={saveWishItem} t={t} icon={<Plus size={15} />} />
        </div>
      </Sheet>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// CYCLE
// ═══════════════════════════════════════════════════════════════════════════════

function CycleScreen({ t }: { t:T }) {
  const [selDay, setSelDay] = useState(1);
  const [selFlow, setSelFlow] = useState("Medium");
  const [selSymp, setSelSymp] = useState<string[]>(["Cramps","Bloating"]);
  const [analytics, setAnalytics] = useState(false);
  const toggle = (s:string) => setSelSymp(p => p.includes(s)?p.filter(x=>x!==s):[...p,s]);

  return (
    <div className="pb-32 px-4 pt-4 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-extrabold" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif", letterSpacing:"-0.02em" }}>Cycle Tracker</h1>
        <motion.button whileTap={{ scale:0.9 }} onClick={() => setAnalytics(!analytics)}
          className="px-3.5 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5"
          style={{ background:analytics?t.ac:t.acS, color:analytics?"#000":t.fg2 }}>
          <BarChart3 size={12} />{analytics?"Log Entry":"Analytics"}
        </motion.button>
      </div>

      <Cal t={t} periodDays={[26,27,28,29,30]} selDay={selDay} onSel={setSelDay} />

      {!analytics ? (
        <>
          <div className="rounded-[22px] p-4 space-y-4" style={{ background:t.card, border:`1px solid ${t.bd}` }}>
            <div>
              <p className="text-base font-bold mb-0.5" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>June {selDay}</p>
              <p className="text-xs" style={{ color:t.fg2 }}>Log your flow and symptoms</p>
            </div>
            <div>
              <MLabel text="Flow Intensity" t={t} />
              <div className="flex gap-2">{FLOW_TYPES.map(f => <Chip key={f} label={f} selected={selFlow===f} onClick={() => setSelFlow(f)} t={t} />)}</div>
            </div>
            <div>
              <MLabel text="Symptoms" t={t} />
              <div className="flex flex-wrap gap-2">{SYMPTOMS.map(s => <Chip key={s} label={s} selected={selSymp.includes(s)} onClick={() => toggle(s)} t={t} />)}</div>
            </div>
            <div>
              <MLabel text="Private Notes" t={t} />
              <textarea placeholder="How are you feeling today?" rows={3}
                className="w-full text-xs p-3 rounded-[12px] resize-none outline-none leading-relaxed"
                style={{ background:t.acS, color:t.fg, border:`1px solid ${t.bd}`, fontFamily:"'DM Sans',sans-serif" }} />
            </div>
            <PrimaryBtn label="Save Entry" t={t} icon={<Check size={15} />} />
          </div>

          <div className="rounded-[22px] p-4" style={{ background:t.card, border:`1px solid ${t.bd}` }}>
            <SHead title="Cycle Insight" t={t} />
            <div className="grid grid-cols-2 gap-2">
              {[
                {label:"Current Phase",value:"Follicular",color:"#4ADE80"},
                {label:"Day of Cycle",value:"Day 18",color:t.ac},
                {label:"Last Period",value:"Jun 26–30",color:"#F064A8"},
                {label:"Est. Next",value:"Jul 23–27",color:"#9B72F0"},
              ].map(({ label, value, color }) => (
                <div key={label} className="p-3 rounded-[12px]" style={{ background:t.acS }}>
                  <div className="text-[9px] font-bold tracking-widest uppercase mb-1" style={{ color:t.fg3 }}>{label}</div>
                  <div className="text-sm font-bold" style={{ color, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>{value}</div>
                </div>
              ))}
            </div>
          </div>
        </>
      ) : (
        <div className="space-y-4">
          <div className="rounded-[22px] p-4" style={{ background:t.card, border:`1px solid ${t.bd}` }}>
            <SHead title="Cycle History (days)" t={t} />
            <ResponsiveContainer width="100%" height={130}>
              <BarChart data={CYC_H} barSize={32} margin={{ top:4, right:0, left:-24, bottom:0 }}>
                <XAxis dataKey="cycle" tick={{ fill:t.fg2, fontSize:10, fontFamily:"'DM Mono',monospace" }} axisLine={false} tickLine={false} />
                <Bar dataKey="length" radius={[7,7,0,0]}>
                  {CYC_H.map((_,i) => <Cell key={i} fill={i===3?t.ac:`${t.ac}35`} />)}
                </Bar>
                <Tooltip contentStyle={{ background:t.cardHi, border:`1px solid ${t.bd}`, borderRadius:12, color:t.fg, fontSize:11 }} formatter={(v:number) => [`${v} days`,"Length"]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {[{label:"Average",value:"28.8 days",icon:"📊",color:t.ac},{label:"Range",value:"27–31 days",icon:"📏",color:"#4ADE80"},{label:"Est. Next",value:"Jul 23–27",icon:"📅",color:"#9B72F0"},{label:"Top Symptom",value:"Cramps",icon:"📌",color:"#F064A8"}].map(({ label,value,icon,color }) => (
              <div key={label} className="p-3.5 rounded-[18px]" style={{ background:t.card, border:`1px solid ${t.bd}` }}>
                <div className="text-xl mb-2">{icon}</div>
                <div className="text-[9px] font-bold tracking-widest uppercase mb-1" style={{ color:t.fg3 }}>{label}</div>
                <div className="text-sm font-bold" style={{ color, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>{value}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// HYDRATION
// ═══════════════════════════════════════════════════════════════════════════════

function HydrationScreen({ t, logs, setLogs, showSnack }: {
  t:T; logs:HLog[]; setLogs:React.Dispatch<React.SetStateAction<HLog[]>>;
  showSnack:(msg:string,undo?:()=>void)=>void;
}) {
  const waterAmount = logs.reduce((s,l) => s+l.amount, 0);
  const goal = 2000;
  const pct = Math.min(100, Math.round((waterAmount/goal)*100));
  const wColor = t.ac === "#E0E0E0" ? "#38A8F0" : t.ac;

  const addLog = (amount:number) => {
    const now = new Date();
    const timeLabel = now.toLocaleTimeString([], { hour:"2-digit", minute:"2-digit" });
    const log: HLog = { id:Date.now(), amount, timeLabel, ts:Date.now() };
    setLogs(p => [log, ...p]);
  };

  const deleteLog = (id:number) => {
    const log = logs.find(l => l.id===id)!;
    setLogs(p => p.filter(l => l.id!==id));
    showSnack(`${log.amount}ml removed`, () => setLogs(p => [log, ...p].sort((a,b) => b.ts-a.ts)));
  };

  return (
    <div className="pb-32 px-4 pt-4 space-y-5">
      <h1 className="text-xl font-extrabold" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif", letterSpacing:"-0.02em" }}>Hydration</h1>

      {/* Main card */}
      <div className="p-6 rounded-[28px] flex flex-col items-center gap-5" style={{ background:t.card, border:`1px solid ${t.bd}` }}>
        <WaterBall pct={pct} color={wColor} />
        <div className="text-center">
          <div className="text-4xl font-extrabold leading-none mb-1" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>
            {waterAmount}<span className="text-base font-medium ml-1.5" style={{ color:t.fg2 }}>ml</span>
          </div>
          <p className="text-xs" style={{ color:t.fg2 }}>of {goal}ml daily goal</p>
        </div>
        <div className="flex gap-3 w-full">
          {[100,250,500].map(amt => (
            <motion.button key={amt} whileTap={{ scale:0.9 }} onClick={() => addLog(amt)}
              className="flex-1 py-3 rounded-[14px] text-xs font-bold flex items-center justify-center gap-1"
              style={{ background:`${wColor}18`, color:wColor, border:`1.5px solid ${wColor}28` }}>
              <Plus size={12} />{amt}ml
            </motion.button>
          ))}
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-2">
        {[{label:"Today",value:`${waterAmount}ml`,color:wColor},{label:"Goal",value:"2000ml",color:t.fg2},{label:"Streak",value:"5 days 🔥",color:t.warn}].map(({ label,value,color }) => (
          <div key={label} className="p-3 rounded-[16px] text-center" style={{ background:t.card, border:`1px solid ${t.bd}` }}>
            <div className="text-sm font-extrabold mb-0.5" style={{ color, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>{value}</div>
            <div className="text-[9px] font-bold uppercase tracking-wider" style={{ color:t.fg3 }}>{label}</div>
          </div>
        ))}
      </div>

      {/* Today's log */}
      <div className="rounded-[22px] p-4" style={{ background:t.card, border:`1px solid ${t.bd}` }}>
        <SHead title="Today's Log" t={t} />
        {logs.length === 0 ? (
          <Empty icon="💧" title="No logs yet" body="Start tracking — tap the buttons above to log your first glass." t={t} />
        ) : (
          <div className="space-y-2">
            <AnimatePresence initial={false}>
              {logs.map(log => (
                <motion.div key={log.id} layout initial={{ opacity:0, y:8 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0, x:-50, height:0 }}>
                  <SwipeRow t={t} onDelete={() => deleteLog(log.id)}>
                    <div className="flex items-center justify-between px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-[10px] flex items-center justify-center text-sm" style={{ background:`${wColor}18` }}>💧</div>
                        <span className="text-sm font-semibold" style={{ color:t.fg }}>{log.amount} ml</span>
                      </div>
                      <span className="text-xs" style={{ color:t.fg3, fontFamily:"'DM Mono',monospace" }}>{log.timeLabel}</span>
                    </div>
                  </SwipeRow>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* Weekly */}
      <div className="rounded-[22px] p-4" style={{ background:t.card, border:`1px solid ${t.bd}` }}>
        <SHead title="This Week" t={t} />
        <ResponsiveContainer width="100%" height={90}>
          <BarChart data={WEEK_W} barSize={22} margin={{ top:4, right:0, left:-24, bottom:0 }}>
            <XAxis dataKey="day" tick={{ fill:t.fg3, fontSize:10, fontFamily:"'DM Mono',monospace" }} axisLine={false} tickLine={false} />
            <Bar dataKey="ml" radius={[6,6,0,0]}>
              {WEEK_W.map((_,i) => <Cell key={i} fill={i===6?wColor:`${wColor}35`} />)}
            </Bar>
            <Tooltip contentStyle={{ background:t.cardHi, border:`1px solid ${t.bd}`, borderRadius:10, color:t.fg, fontSize:11 }} formatter={(v:number) => [`${v}ml`,"Intake"]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// SETTINGS
// ═══════════════════════════════════════════════════════════════════════════════

function SettingsScreen({ t, reminders, setReminders, activeTheme, setActiveTheme, showSnack, showConfirm }: {
  t:T; reminders:RItem[]; setReminders:React.Dispatch<React.SetStateAction<RItem[]>>;
  activeTheme:string; setActiveTheme:(k:string)=>void;
  showSnack:(msg:string,undo?:()=>void)=>void;
  showConfirm:(title:string,body:string,onOk:()=>void)=>void;
}) {
  const [sTab, setSTab] = useState<"reminders"|"themes"|"backup">("reminders");
  const [catFilter, setCatFilter] = useState("All");
  const [rSheetOpen, setRSheetOpen] = useState(false);
  const [rLabel, setRLabel] = useState("");
  const [rTime, setRTime] = useState("08:00");
  const [rCat, setRCat] = useState("Medication");
  const [rIcon, setRIcon] = useState("💊");
  const [rDays, setRDays] = useState<number[]>([0,1,2,3,4,5,6]);

  const cats = ["All","Medication","Water","Skincare","General Care"];
  const dayL = ["M","T","W","T","F","S","S"];
  const catIcons: Record<string,string> = {"Medication":"💊","Water":"💧","Skincare":"✨","General Care":"⭐"};

  const toggleDay = (d:number) => setRDays(p => p.includes(d)?p.filter(x=>x!==d):[...p,d].sort());

  const saveReminder = () => {
    if (!rLabel.trim()) return;
    const now = Date.now();
    setReminders(p => [{ id:now, label:rLabel, time:rTime, cat:rCat, icon:rIcon, days:rDays, active:true, ts:now }, ...p]);
    setRSheetOpen(false);
    setRLabel(""); setRTime("08:00"); setRCat("Medication"); setRIcon("💊"); setRDays([0,1,2,3,4,5,6]);
    showSnack("Reminder created 🔔");
  };

  const deleteReminder = (id:number) => {
    const r = reminders.find(x => x.id===id)!;
    showConfirm("Delete reminder?","This reminder will be permanently removed.", () => {
      setReminders(p => p.filter(x => x.id!==id));
      showSnack("Reminder deleted", () => setReminders(p => [r, ...p].sort((a,b)=>a.ts-b.ts)));
    });
  };

  const filtered = reminders.filter(r => catFilter==="All" || r.cat===catFilter);

  return (
    <>
      <div className="pb-32 px-4 pt-4 space-y-4">
        <h1 className="text-xl font-extrabold" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif", letterSpacing:"-0.02em" }}>Settings</h1>

        <div className="flex gap-1 p-1 rounded-[16px]" style={{ background:t.card }}>
          {[{k:"reminders",l:"🔔 Alerts"},{k:"themes",l:"🎨 Themes"},{k:"backup",l:"☁️ Backup"}].map(({ k,l }) => (
            <button key={k} onClick={() => setSTab(k as "reminders"|"themes"|"backup")}
              className="flex-1 py-2 rounded-[12px] text-[10px] font-bold transition-all"
              style={{ background:sTab===k?t.ac:"transparent", color:sTab===k?"#000":t.fg2 }}>
              {l}
            </button>
          ))}
        </div>

        {sTab==="reminders" && (
          <>
            <div className="flex gap-2 overflow-x-auto -mx-1 px-1 pb-0.5 hs">
              {cats.map(c => (
                <button key={c} onClick={() => setCatFilter(c)}
                  className="px-3 py-1.5 rounded-full text-xs font-semibold shrink-0"
                  style={{ background:catFilter===c?t.ac:t.acS, color:catFilter===c?"#000":t.fg2, border:`1px solid ${catFilter===c?t.ac:t.bd}` }}>
                  {c}
                </button>
              ))}
            </div>

            {filtered.length === 0 ? (
              <Empty icon="🔔" title="No reminders here" body="Create a reminder to stay on top of your wellness routine." action="Add reminder" onAction={() => setRSheetOpen(true)} t={t} />
            ) : (
              <div className="space-y-3">
                <AnimatePresence initial={false}>
                  {filtered.map((r, i) => (
                    <motion.div key={r.id} layout initial={{ opacity:0, y:8 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0, x:-60, height:0 }} transition={{ delay:i<5?i*0.05:0 }}>
                      <SwipeRow t={t} onDelete={() => deleteReminder(r.id)}>
                        <div className="p-4">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex items-start gap-3">
                              <div className="w-10 h-10 rounded-[13px] flex items-center justify-center text-xl" style={{ background:t.acS }}>{r.icon}</div>
                              <div>
                                <div className="text-sm font-bold mb-0.5" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>{r.label}</div>
                                <div className="flex items-center gap-2">
                                  <span className="text-[9px] px-2 py-0.5 rounded-full" style={{ background:t.acS, color:t.fg2 }}>{r.cat}</span>
                                  <span className="text-[10px]" style={{ color:t.fg3, fontFamily:"'DM Mono',monospace" }}>{r.time}</span>
                                </div>
                              </div>
                            </div>
                            <Toggle active={r.active} onChange={() => setReminders(p => p.map(x => x.id===r.id?{...x,active:!x.active}:x))} t={t} />
                          </div>
                          <div className="flex gap-1.5">
                            {dayL.map((d,i2) => (
                              <div key={i2} className="w-7 h-7 rounded-full flex items-center justify-center text-[9px] font-bold"
                                style={{ background:r.days.includes(i2)?`${t.ac}22`:t.acS, color:r.days.includes(i2)?t.ac:t.fg3 }}>{d}</div>
                            ))}
                          </div>
                        </div>
                      </SwipeRow>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </>
        )}

        {sTab==="themes" && (
          <div className="space-y-3">
            <p className="text-xs leading-relaxed" style={{ color:t.fg2 }}>Choose your personal wellness palette. Changes apply instantly.</p>
            <div className="grid grid-cols-2 gap-3">
              {Object.entries(THEMES).map(([key, th]) => {
                const on = activeTheme===key;
                return (
                  <motion.button key={key} whileTap={{ scale:0.94 }} onClick={() => setActiveTheme(key)}
                    className="p-4 rounded-[22px] text-left"
                    style={{ background:th.card, border:`2px solid ${on?th.ac:th.bd}`, boxShadow:on?`0 0 0 1px ${th.ac}25`:"none" }}>
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background:th.bg, border:`1.5px solid ${th.ac}` }}>
                        {on ? <Check size={13} color={th.ac} /> : <span className="text-base">{th.emoji}</span>}
                      </div>
                      <div className="flex gap-1">
                        <div className="w-3.5 h-3.5 rounded-full" style={{ background:th.sw }} />
                        <div className="w-3 h-3 rounded-full opacity-60 mt-0.5" style={{ background:th.ac }} />
                      </div>
                    </div>
                    <div className="text-sm font-bold mb-2" style={{ color:th.fg, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>{th.name}</div>
                    <div className="space-y-1.5">
                      <div className="h-1.5 rounded-full" style={{ background:th.ac, width:"65%" }} />
                      <div className="h-1 rounded-full opacity-35" style={{ background:th.fg2, width:"85%" }} />
                      <div className="h-1 rounded-full opacity-20" style={{ background:th.fg2, width:"50%" }} />
                    </div>
                  </motion.button>
                );
              })}
            </div>
          </div>
        )}

        {sTab==="backup" && (
          <div className="space-y-4">
            <div className="p-4 rounded-[16px] flex items-center gap-3" style={{ background:t.acS, border:`1px solid ${t.bd}` }}>
              <span className="text-xl">🔒</span>
              <p className="text-xs leading-relaxed" style={{ color:t.fg2 }}>Abantika never uploads your data. Everything stays private and offline on your device.</p>
            </div>
            {[
              {icon:Download,title:"Export Data",desc:"Save all your entries, logs, and settings as a secure encrypted file.",action:"Export Now",color:t.ac},
              {icon:Upload,title:"Restore Data",desc:"Import a backup file to restore your complete Abantika history.",action:"Choose File",color:t.fg2},
            ].map(({ icon:Icon,title,desc,action,color }) => (
              <div key={title} className="p-5 rounded-[24px]" style={{ background:t.card, border:`1px solid ${t.bd}` }}>
                <div className="w-12 h-12 rounded-[16px] flex items-center justify-center mb-4" style={{ background:`${color}15` }}>
                  <Icon size={20} color={color} />
                </div>
                <div className="text-base font-bold mb-1.5" style={{ color:t.fg, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>{title}</div>
                <p className="text-xs leading-relaxed mb-4" style={{ color:t.fg2 }}>{desc}</p>
                <motion.button whileTap={{ scale:0.96 }} className="w-full py-3 rounded-[14px] text-sm font-bold"
                  style={{ background:`${color}15`, color, border:`1px solid ${color}25` }}>{action}</motion.button>
              </div>
            ))}
          </div>
        )}
      </div>

      {sTab==="reminders" && (
        <motion.button whileTap={{ scale:0.88 }} onClick={() => setRSheetOpen(true)}
          className="fixed z-40 w-14 h-14 rounded-full flex items-center justify-center shadow-2xl"
          style={{ bottom:100, right:20, background:t.ac, boxShadow:`0 8px 32px ${t.ac}60` }}>
          <Plus size={24} color="#000" />
        </motion.button>
      )}

      <Sheet open={rSheetOpen} onClose={() => setRSheetOpen(false)} title="New Reminder" t={t}>
        <div className="px-5 pb-6 space-y-4">
          <div>
            <MLabel text="Label" t={t} />
            <input value={rLabel} onChange={e => setRLabel(e.target.value)} placeholder="e.g. Evening supplements"
              className="w-full text-sm p-3 rounded-[12px] outline-none"
              style={{ background:t.acS, color:t.fg, border:`1px solid ${t.bd}` }} />
          </div>
          <div>
            <MLabel text="Time" t={t} />
            <input type="time" value={rTime} onChange={e => setRTime(e.target.value)}
              className="w-full text-sm p-3 rounded-[12px] outline-none"
              style={{ background:t.acS, color:t.fg, border:`1px solid ${t.bd}` }} />
          </div>
          <div>
            <MLabel text="Category" t={t} />
            <div className="flex gap-2 flex-wrap">
              {["Medication","Water","Skincare","General Care"].map(c => (
                <Chip key={c} label={c} selected={rCat===c} onClick={() => { setRCat(c); setRIcon(catIcons[c]||"⭐"); }} t={t} />
              ))}
            </div>
          </div>
          <div>
            <MLabel text="Days" t={t} />
            <div className="flex gap-2">
              {dayL.map((d,i) => (
                <motion.button key={i} whileTap={{ scale:0.82 }} onClick={() => toggleDay(i)}
                  className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold"
                  style={{ background:rDays.includes(i)?t.ac:t.acS, color:rDays.includes(i)?"#000":t.fg2 }}>{d}</motion.button>
              ))}
            </div>
          </div>
          <PrimaryBtn label="Create Reminder" onClick={saveReminder} t={t} icon={<Bell size={15} />} />
        </div>
      </Sheet>
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// APP ROOT
// ═══════════════════════════════════════════════════════════════════════════════

export default function App() {
  const [activeTab, setActiveTab] = useState("home");
  const [activeTheme, setActiveTheme] = useState("monoNoir");
  const [journal, setJournal] = useState<JEntry[]>(INIT_J);
  const [reminders, setReminders] = useState<RItem[]>(INIT_R);
  const [wishlist, setWishlist] = useState<WItem[]>(INIT_W);
  const [hydrationLogs, setHydrationLogs] = useState<HLog[]>(INIT_H);
  const [mood, setMood] = useState("😊");
  const [snack, setSnack] = useState<Snack>(null);
  const [confirm, setConfirm] = useState<Confirm>(null);

  const th = THEMES[activeTheme];
  const waterAmount = hydrationLogs.reduce((s,l) => s+l.amount, 0);

  const showSnack = (msg:string, undo?:()=>void) => setSnack({ msg, undo });
  const showConfirm = (title:string, body:string, onOk:()=>void) => setConfirm({ title, body, onOk });

  const renderScreen = () => {
    switch (activeTab) {
      case "home":     return <Dashboard t={th} waterAmount={waterAmount} mood={mood} jEntries={journal} setTab={setActiveTab} />;
      case "cycle":    return <CycleScreen t={th} />;
      case "journal":  return <JournalScreen t={th} journal={journal} setJournal={setJournal} wishlist={wishlist} setWishlist={setWishlist} mood={mood} setMood={setMood} showSnack={showSnack} showConfirm={showConfirm} />;
      case "water":    return <HydrationScreen t={th} logs={hydrationLogs} setLogs={setHydrationLogs} showSnack={showSnack} />;
      case "settings": return <SettingsScreen t={th} reminders={reminders} setReminders={setReminders} activeTheme={activeTheme} setActiveTheme={setActiveTheme} showSnack={showSnack} showConfirm={showConfirm} />;
      default:         return null;
    }
  };

  return (
    <div className="min-h-screen w-full flex items-start justify-center" style={{ background:"#020202", fontFamily:"'DM Sans',sans-serif" }}>
      <style>{G}</style>

      <motion.div className="relative w-full max-w-[430px] overflow-hidden"
        style={{ minHeight:"100svh" }}
        animate={{ background:th.bg }}
        transition={{ duration:0.45, ease:"easeInOut" }}>

        <StatusBar t={th} />

        <motion.div key={activeTab}
          initial={{ opacity:0, y:10 }}
          animate={{ opacity:1, y:0 }}
          transition={{ duration:0.22, ease:[0.25,0.46,0.45,0.94] }}
          className="overflow-y-auto hs"
          style={{ height:"calc(100svh - 48px)" }}>
          {renderScreen()}
        </motion.div>

        <BNav active={activeTab} onChange={setActiveTab} t={th} />

        <Snackbar snack={snack} dismiss={() => setSnack(null)} t={th} />
        <ConfirmDlg confirm={confirm} dismiss={() => setConfirm(null)} t={th} />
      </motion.div>
    </div>
  );
}
