Transform the entire application into a flagship, Dribbble-quality mobile experience while preserving every existing feature and workflow.

Do NOT rebuild the app from scratch.
Do NOT remove functionality.
This is a visual and UX refinement pass focused on premium craftsmanship.

## Overall Design Direction

The app should feel comparable to the highest-quality wellness applications on the App Store.

Inspiration:

• Headspace
• Stoic
• Calm
• Reflectly
• Finch
• Apple Health
• Notion Calendar
• Linear (clean interaction quality)

The experience should feel luxurious, warm, personal, elegant, and handcrafted.

Avoid generic Material Design or template-like layouts.

---

## Visual System

Create a cohesive design system.

Use:

- 8px spacing grid
- 20–28px rounded corners
- Large hero sections
- Premium typography hierarchy
- Beautiful iconography (Lucide with custom styling)
- Soft layered shadows
- Subtle gradients
- Frosted glass only where tasteful
- Large touch targets
- Consistent card layouts
- Excellent visual balance

Everything should feel intentional.

---

## Color System

Improve every theme.

Create proper design tokens for:

- Background
- Elevated background
- Surface
- Surface secondary
- Primary
- Secondary
- Accent
- Success
- Warning
- Error
- Border
- Divider
- Text Primary
- Text Secondary
- Text Tertiary

Ensure excellent contrast.

---

## Typography

Use a premium type scale.

Display
Headline
Title
Body
Caption
Label

Improve font weights and spacing.

Avoid dense text.

Increase readability.

---

## Icons

Refine all icons.

Use:

- Consistent stroke width
- Soft circular backgrounds
- Small animated interactions
- Premium spacing

Icons should feel elegant.

---

## Dashboard

Redesign the dashboard.

Create:

Large hero greeting

Beautiful greeting animation

Floating quick actions

Layered cards

Improved spacing

Animated progress indicators

Gradient accents

Glass highlights

Animated wave hydration card

Mood card with expressive emoji animations

Reminder countdown card

Daily encouragement card

Habit streak summary

Everything should scroll beautifully.

---

## Journal

Create a premium journaling experience.

Large writing area.

Beautiful empty state.

Elegant calendar.

Animated day selection.

Floating formatting toolbar.

Paper-like writing experience.

Smooth keyboard transitions.

Mood stickers should animate.

---

## Statistics

Create premium analytics.

Use animated charts.

Circular progress.

Area graphs.

Bar charts.

Heatmaps.

Smooth transitions.

Beautiful loading animations.

No raw numbers floating randomly.

Everything should have hierarchy.

---

## Habits

Design habit cards with:

Gradient backgrounds

Animated completion

Expanding details

Current streak

Longest streak

Completion ring

Swipe actions

Micro interactions

Completion celebration

---

## Wishlist

Transform wishlist into a luxury shopping inspiration board.

Large image cards.

Elegant labels.

Soft shadows.

Beautiful category tabs.

Premium add-item modal.

---

## Reminders

Redesign reminder cards.

Timeline layout.

Beautiful switches.

Animated enable/disable.

Elegant time picker.

Category badges.

Smooth deletion animation.

---

## Settings

Completely redesign settings.

Grouped sections.

Beautiful tiles.

Animated toggles.

Theme previews.

Backup cards.

About screen.

Premium appearance.

---

## Theme Picker

Create a stunning theme gallery.

Each theme displayed as:

Large preview card

Color swatches

Mini device preview

Animated selection

Instant transition

Persist selection.

---

## Empty States

Every page should have custom illustrations or tasteful icons.

Examples:

No journal entries

No reminders

No wishlist items

No habits

No mood logs

No hydration

Each should include encouraging copy.

---

## Motion Design

Upgrade every interaction.

Include:

Shared element transitions

Ripple feedback

Animated counters

Card elevation

Fade animations

Slide transitions

Scale interactions

Floating Action Button morphing

Hero animations

Spring physics

Skeleton loading

Staggered list animations

Smooth page transitions

Avoid excessive animation.

Everything should feel premium.

---

## Micro-Interactions

Buttons slightly scale when tapped.

Cards gently lift.

Charts animate into view.

Numbers count smoothly.

Progress bars animate.

FAB morphs into dialogs.

Theme changes crossfade elegantly.

Confetti for milestones.

Subtle haptics where supported.

---

## Accessibility

Maintain:

High contrast

Dynamic font sizes

Screen readers

Reduced motion

Large touch targets

Keyboard navigation

Proper ARIA labels

---

## Performance

Despite the visual improvements:

Maintain 60 FPS animations.

Lazy-load heavy components.

Optimize rendering.

Prevent unnecessary re-renders.

Keep bundle size efficient.

---

## Final Goal

Every screen should look like a featured Dribbble shot while remaining fully functional, intuitive, and production-ready.

The app should feel like a premium paid wellness companion that could win a mobile design award.