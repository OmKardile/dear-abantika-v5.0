sed -i 's/baseColor.value.toLong().toInt()/androidx.compose.ui.graphics.toArgb(baseColor)/g' app/src/main/java/com/example/ui/screens/CareDashboard.kt
sed -i 's/MaterialTheme.colorScheme.surface.value.toLong().toInt()/androidx.compose.ui.graphics.toArgb(MaterialTheme.colorScheme.surface)/g' app/src/main/java/com/example/ui/screens/CareDashboard.kt
