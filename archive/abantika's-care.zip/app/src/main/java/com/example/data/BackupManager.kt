package com.example.data

import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.flow.first

class BackupManager(private val repository: CareRepository) {

    suspend fun exportDataToJson(): String {
        val root = JSONObject()
        
        // Hydration
        val hydrationList = repository.allHydration.first()
        val hydrationArray = JSONArray()
        for (item in hydrationList) {
            val obj = JSONObject()
            obj.put("date", item.date)
            obj.put("amountMl", item.amountMl)
            obj.put("timestamp", item.timestamp)
            hydrationArray.put(obj)
        }
        root.put("hydration", hydrationArray)

        // Menstrual
        val menstrualList = repository.allMenstrual.first()
        val menstrualArray = JSONArray()
        for (item in menstrualList) {
            val obj = JSONObject()
            obj.put("startDate", item.startDate)
            obj.put("endDate", item.endDate ?: JSONObject.NULL)
            obj.put("flowLevel", item.flowLevel)
            obj.put("symptoms", item.symptoms)
            obj.put("notes", item.notes)
            menstrualArray.put(obj)
        }
        root.put("menstrual", menstrualArray)

        // Moods
        val journalList = repository.allJournals.first()
        val journalArray = JSONArray()
        for (item in journalList) {
            val obj = JSONObject()
            obj.put("date", item.date)
            obj.put("mood", item.mood)
            obj.put("note", item.note)
            obj.put("activities", item.activities)
            obj.put("timestamp", item.timestamp)
            obj.put("title", item.title)
            obj.put("lastEdited", item.lastEdited)
            obj.put("stickers", item.stickers)
            journalArray.put(obj)
        }
        root.put("journals", journalArray)

        // Reminders
        val reminderList = repository.allReminders.first()
        val reminderArray = JSONArray()
        for (item in reminderList) {
            val obj = JSONObject()
            obj.put("title", item.title)
            obj.put("message", item.message)
            obj.put("time", item.time)
            obj.put("daysOfWeek", item.daysOfWeek)
            obj.put("isEnabled", item.isEnabled)
            reminderArray.put(obj)
        }
        root.put("reminders", reminderArray)

        // Shopping Items
        val shoppingList = repository.allShoppingItems.first()
        val shoppingArray = JSONArray()
        for (item in shoppingList) {
            val obj = JSONObject()
            obj.put("category", item.category)
            obj.put("url", item.url)
            obj.put("title", item.title)
            obj.put("note", item.note)
            obj.put("imageUrl", item.imageUrl)
            obj.put("timestamp", item.timestamp)
            shoppingArray.put(obj)
        }
        root.put("shopping", shoppingArray)

        return root.toString(2)
    }

    suspend fun importDataFromJson(jsonStr: String): Boolean {
        return try {
            val root = JSONObject(jsonStr)

            // Import hydration
            if (root.has("hydration")) {
                val array = root.getJSONArray("hydration")
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    repository.insertHydration(
                        HydrationRecord(
                            date = obj.getString("date"),
                            amountMl = obj.getInt("amountMl"),
                            timestamp = obj.getLong("timestamp")
                        )
                    )
                }
            }

            // Import menstrual
            if (root.has("menstrual")) {
                val array = root.getJSONArray("menstrual")
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val endDate = if (obj.isNull("endDate")) null else obj.getString("endDate")
                    repository.insertMenstrual(
                        MenstrualRecord(
                            startDate = obj.getString("startDate"),
                            endDate = endDate,
                            flowLevel = obj.optString("flowLevel", "Medium"),
                            symptoms = obj.optString("symptoms", ""),
                            notes = obj.optString("notes", "")
                        )
                    )
                }
            }

            // Import journals
            if (root.has("journals")) {
                val array = root.getJSONArray("journals")
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    repository.insertJournal(
                        MoodJournal(
                            date = obj.getString("date"),
                            mood = obj.getString("mood"),
                            note = obj.getString("note"),
                            activities = obj.optString("activities", ""),
                            timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                            title = obj.optString("title", ""),
                            lastEdited = obj.optLong("lastEdited", System.currentTimeMillis()),
                            stickers = obj.optString("stickers", "")
                        )
                    )
                }
            }

            // Import reminders
            if (root.has("reminders")) {
                val array = root.getJSONArray("reminders")
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    repository.insertReminder(
                        CustomReminder(
                            title = obj.getString("title"),
                            message = obj.getString("message"),
                            time = obj.getString("time"),
                            daysOfWeek = obj.optString("daysOfWeek", "Mon,Tue,Wed,Thu,Fri,Sat,Sun"),
                            isEnabled = obj.optBoolean("isEnabled", true)
                        )
                    )
                }
            }

            // Import shopping
            if (root.has("shopping")) {
                val array = root.getJSONArray("shopping")
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    repository.insertShoppingItem(
                        ShoppingItem(
                            category = obj.getString("category"),
                            url = obj.optString("url", ""),
                            title = obj.getString("title"),
                            note = obj.optString("note", ""),
                            imageUrl = obj.optString("imageUrl", ""),
                            timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                        )
                    )
                }
            }

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
