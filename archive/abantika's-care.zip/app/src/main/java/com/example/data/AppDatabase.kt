package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// --- Entities ---

@Entity(tableName = "hydration_records")
data class HydrationRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String, // "yyyy-MM-dd"
    val amountMl: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "menstrual_records")
data class MenstrualRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val startDate: String, // "yyyy-MM-dd"
    val endDate: String? = null, // "yyyy-MM-dd", null if active
    val flowLevel: String = "Medium", // "Light", "Medium", "Heavy"
    val symptoms: String = "", // Comma-separated
    val notes: String = ""
)

@Entity(tableName = "mood_journals")
data class MoodJournal(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String, // "yyyy-MM-dd"
    val mood: String, // "Happy", "Excited", "Calm", "Tired", "Sad", "Anxious", "Stressed", "Angry", "Motivated"
    val note: String,
    val activities: String = "", // Comma-separated
    val timestamp: Long = System.currentTimeMillis(),
    val title: String = "",
    val lastEdited: Long = System.currentTimeMillis(),
    val stickers: String = "" // Comma-separated stickers
)

@Entity(tableName = "custom_reminders")
data class CustomReminder(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val message: String,
    val time: String, // "HH:mm"
    val daysOfWeek: String, // "Mon,Tue,Wed,Thu,Fri,Sat,Sun"
    val isEnabled: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "shopping_items")
data class ShoppingItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val category: String, // "Save for Later", "Urgent Need", "For Him", "Dream Cart"
    val url: String,
    val title: String,
    val note: String,
    val imageUrl: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

// --- DAOs ---

@Dao
interface HydrationDao {
    @Query("SELECT * FROM hydration_records ORDER BY timestamp DESC")
    fun getAll(): Flow<List<HydrationRecord>>

    @Query("SELECT * FROM hydration_records WHERE date = :date")
    fun getByDate(date: String): Flow<List<HydrationRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: HydrationRecord)

    @Delete
    suspend fun delete(record: HydrationRecord)

    @Query("DELETE FROM hydration_records WHERE id = :id")
    suspend fun deleteById(id: Int)
}

@Dao
interface MenstrualDao {
    @Query("SELECT * FROM menstrual_records ORDER BY startDate DESC")
    fun getAll(): Flow<List<MenstrualRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: MenstrualRecord)

    @Delete
    suspend fun delete(record: MenstrualRecord)

    @Query("DELETE FROM menstrual_records WHERE id = :id")
    suspend fun deleteById(id: Int)
}

@Dao
interface JournalDao {
    @Query("SELECT * FROM mood_journals ORDER BY date DESC, timestamp DESC")
    fun getAll(): Flow<List<MoodJournal>>

    @Query("SELECT * FROM mood_journals WHERE date = :date LIMIT 1")
    suspend fun getByDate(date: String): MoodJournal?

    @Query("SELECT * FROM mood_journals WHERE date = :date")
    fun getByDateFlow(date: String): Flow<List<MoodJournal>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(journal: MoodJournal)

    @Delete
    suspend fun delete(journal: MoodJournal)

    @Query("DELETE FROM mood_journals WHERE id = :id")
    suspend fun deleteById(id: Int)
}

@Dao
interface ReminderDao {
    @Query("SELECT * FROM custom_reminders ORDER BY timestamp DESC")
    fun getAll(): Flow<List<CustomReminder>>

    @Query("SELECT * FROM custom_reminders WHERE isEnabled = 1")
    suspend fun getActiveReminders(): List<CustomReminder>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(reminder: CustomReminder)

    @Delete
    suspend fun delete(reminder: CustomReminder)

    @Query("DELETE FROM custom_reminders WHERE id = :id")
    suspend fun deleteById(id: Int)
}

@Dao
interface ShoppingDao {
    @Query("SELECT * FROM shopping_items ORDER BY timestamp DESC")
    fun getAll(): Flow<List<ShoppingItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: ShoppingItem)

    @Delete
    suspend fun delete(item: ShoppingItem)

    @Query("DELETE FROM shopping_items WHERE id = :id")
    suspend fun deleteById(id: Int)
}

// --- App Database ---

@Database(
    entities = [
        HydrationRecord::class,
        MenstrualRecord::class,
        MoodJournal::class,
        CustomReminder::class,
        ShoppingItem::class
    ],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun hydrationDao(): HydrationDao
    abstract fun menstrualDao(): MenstrualDao
    abstract fun journalDao(): JournalDao
    abstract fun reminderDao(): ReminderDao
    abstract fun shoppingDao(): ShoppingDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "abantika_care_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
