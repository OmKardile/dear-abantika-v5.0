package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.R
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.CareViewModel
import com.example.viewmodel.SyncStatus
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun CareDashboard(
    viewModel: CareViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf("dashboard") }
    var isSettingsOpen by remember { mutableStateOf(false) }
    var isRemindersOpen by remember { mutableStateOf(false) }

    val selectedDate by viewModel.selectedDate.collectAsStateWithLifecycle()
    val hydrationList by viewModel.hydrationHistory.collectAsStateWithLifecycle()
    val menstrualList by viewModel.menstrualHistory.collectAsStateWithLifecycle()
    val journalList by viewModel.journalHistory.collectAsStateWithLifecycle()
    val remindersList by viewModel.remindersList.collectAsStateWithLifecycle()
    val shoppingItems by viewModel.shoppingItems.collectAsStateWithLifecycle()

    val todayHydration by viewModel.todayHydration.collectAsStateWithLifecycle()
    val todayJournal by viewModel.todayJournal.collectAsStateWithLifecycle()

    val totalDrunkToday = remember(todayHydration) { todayHydration.sumOf { it.amountMl } }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.surfaceVariant,
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Abantika's Care",
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.SansSerif,
                            color = MaterialTheme.colorScheme.onBackground,
                            fontSize = 20.sp
                        )
                        Text(
                            text = "✨ Abantika Kardile ✨",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { isRemindersOpen = true }) {
                        Icon(
                            imageVector = Icons.Filled.Notifications,
                            contentDescription = "Reminders",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(onClick = { isSettingsOpen = true }) {
                        Icon(
                            imageVector = Icons.Filled.Settings,
                            contentDescription = "Settings & Backup",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                listOf(
                    Triple("dashboard", "Dashboard", Icons.Filled.Dashboard),
                    Triple("cycle", "Cycle", Icons.Filled.CalendarMonth),
                    Triple("water", "Hydration", Icons.Filled.WaterDrop),
                    Triple("journal", "Journal", Icons.Filled.Edit),
                    Triple("shopping", "Shopping", Icons.Filled.ShoppingCart)
                ).forEach { (tabId, label, icon) ->
                    NavigationBarItem(
                        selected = selectedTab == tabId,
                        onClick = { selectedTab = tabId },
                        label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                        icon = { Icon(icon, contentDescription = label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            unselectedIconColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.6f),
                            unselectedTextColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.6f),
                            indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            // Day selector strip
            DateSelectionStrip(
                selectedDate = selectedDate,
                onDateSelected = { viewModel.setSelectedDate(it) },
                onTodayClick = { viewModel.setSelectedDate(viewModel.getTodayDateString()) }
            )

            // Dynamic view content
            Box(modifier = Modifier.weight(1f)) {
                when (selectedTab) {
                    "dashboard" -> DashboardView(
                        totalDrunk = totalDrunkToday,
                        menstrualList = menstrualList,
                        todayJournal = todayJournal,
                        reminders = remindersList,
                        onNavigate = { selectedTab = it },
                        viewModel = viewModel
                    )
                    "cycle" -> MenstrualView(
                        records = menstrualList,
                        onAddLog = { start, end, flow, symps, note ->
                            viewModel.addMenstrualLog(start, end, flow, symps, note)
                        },
                        onDeleteLog = { id -> viewModel.deleteMenstrualLog(id) }
                    )
                    "water" -> HydrationView(
                        records = todayHydration,
                        totalDrunk = totalDrunkToday,
                        onAddWater = { viewModel.addWater(it) },
                        onDeleteRecord = { viewModel.deleteWater(it) }
                    )
                    "journal" -> JournalView(
                        viewModel = viewModel
                    )
                    "shopping" -> ShoppingView(
                        items = shoppingItems,
                        viewModel = viewModel
                    )
                }
            }
        }
    }

    // Modal Settings & Reminders
    if (isSettingsOpen) {
        SettingsDialog(
            viewModel = viewModel,
            onDismiss = { isSettingsOpen = false }
        )
    }

    if (isRemindersOpen) {
        RemindersDialog(
            reminders = remindersList,
            viewModel = viewModel,
            onDismiss = { isRemindersOpen = false }
        )
    }
}

// --- Dynamic Date Selection Strip ---

@Composable
fun DateSelectionStrip(
    selectedDate: String,
    onDateSelected: (String) -> Unit,
    onTodayClick: () -> Unit
) {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val displayFmt = SimpleDateFormat("dd MMM", Locale.getDefault())
    val dayFmt = SimpleDateFormat("E", Locale.getDefault())

    val todayCal = Calendar.getInstance()

    // Calculate last 7 days and next 2 days to list
    val days = remember {
        List(9) { idx ->
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, idx - 6) // List starts from 6 days ago
            cal.time
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Tracking Date: ${formatDisplayDate(selectedDate)}",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onBackground
            )

            TextButton(
                onClick = onTodayClick,
                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("Today", fontSize = 13.sp)
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(bottom = 8.dp, start = 12.dp, end = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            days.forEach { date ->
                val dateStr = sdf.format(date)
                val isSelected = dateStr == selectedDate
                val isToday = sdf.format(Date()) == dateStr

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isSelected) MaterialTheme.colorScheme.primary
                            else if (isToday) MaterialTheme.colorScheme.secondary
                            else MaterialTheme.colorScheme.background
                        )
                        .clickable { onDateSelected(dateStr) }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = dayFmt.format(date).uppercase(),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = displayFmt.format(date),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}// --- Standard Dashboard View ---

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardView(
    totalDrunk: Int,
    menstrualList: List<MenstrualRecord>,
    todayJournal: MoodJournal?,
    reminders: List<CustomReminder>,
    onNavigate: (String) -> Unit,
    viewModel: CareViewModel
) {
    val stats = remember(menstrualList) { calculateCycleStats(menstrualList) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Bento Style Header Row
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Hi, Abantika! 🌸",
                        color = MaterialTheme.colorScheme.onBackground,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.SansSerif
                    )
                    Text(
                        text = "You're doing amazing today.",
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.85f),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // --- BENTO GRID CARD 1: Cycle Tracker (col-span-2) ---
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate("cycle") }
                    .padding(vertical = 2.dp),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.tertiaryContainer)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp)
                ) {
                    val daysLeft = stats?.daysUntilSub ?: 12
                    val phase = stats?.currentPhase ?: "Ovulation"
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(MaterialTheme.colorScheme.tertiaryContainer)
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Cycle Tracker",
                                color = MaterialTheme.colorScheme.onTertiaryContainer,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = if (stats != null) "$phase" else "Day 14 • Ovulation",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "🌸",
                            fontSize = 38.sp
                        )
                        Column {
                            Text(
                                text = if (stats != null) "Next period in $daysLeft days" else "Next period in 12 days",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (stats != null) "Phase: ${stats.currentPhase}" else "Medium chance of pregnancy",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Progress Bar
                    val progressValue = if (stats != null) {
                        ((28 - stats.daysUntilSub).coerceIn(0, 28) / 28f)
                    } else {
                        0.5f // Default grid representation placeholder
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(progressValue)
                                .fillMaxHeight()
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.onTertiaryContainer)
                        )
                    }
                }
            }
        }

        // --- BENTO GRID CARD 2 & 3: Hydration & Mood (Side by Side Grid Row) ---
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Hydration Card
                val context = LocalContext.current
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigate("water") },
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.tertiaryContainer)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "💧",
                            fontSize = 36.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        
                        val formattedLiters = String.format(Locale.US, "%.1fL", totalDrunk / 1000.0)
                        Text(
                            text = formattedLiters,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Text(
                            text = "HYDRATION",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black.copy(alpha = 0.75f),
                            letterSpacing = 1.sp
                        )
                        
                        Spacer(modifier = Modifier.height(10.dp))
                        
                        // Add water action button
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surface)
                                .clickable {
                                    viewModel.addWater(250)
                                    Toast.makeText(context, "Logged 250ml water 💧", Toast.LENGTH_SHORT).show()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "+",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Mood Check Card
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigate("journal") },
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                            .height(145.dp), // Match Hydration card height roughly
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (todayJournal != null) getMoodEmoji(todayJournal.mood) else "✨",
                            fontSize = 32.sp
                        )
                        Column {
                            Text(
                                text = if (todayJournal != null) todayJournal.mood else "Mood Check",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = if (todayJournal != null) todayJournal.note else "How are you feeling, sweetie?",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.75f),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                lineHeight = 12.sp
                            )
                        }
                        
                        Button(
                            onClick = { onNavigate("journal") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(28.dp),
                            contentPadding = PaddingValues(0.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = if (todayJournal != null) "VIEW DAILY" else "LOG NOW",
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // --- BENTO GRID CARD 4: Reminders & Alerts (col-span-2) ---
        item {
            val nextReminder = reminders.filter { it.isEnabled }.minByOrNull { it.time }
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(MaterialTheme.colorScheme.surface),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("⏰", fontSize = 20.sp)
                        }
                        Column {
                            Text(
                                text = nextReminder?.title ?: "No active reminders",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                            Text(
                                text = if (nextReminder != null) "At ${nextReminder.time}" else "Setup custom alerts in top bar",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.75f),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                    if (nextReminder != null) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "✓",
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // --- BENTO GRID CARD 5: Daily Journal summary (col-span-2) ---
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate("journal") }
                    .padding(vertical = 2.dp),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("📝", fontSize = 22.sp)
                        Column {
                            Text(
                                text = "Daily Journal",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (todayJournal != null) todayJournal.note else "\"Today was so productive...\"",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontStyle = FontStyle.Italic,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.onTertiaryContainer)
                    )
                }
            }
        }

        // --- BENTO GRID CARD 6: Friendly Custom Coach Advice Banner ---
        item {
            val moodAdvice = remember(todayJournal) {
                getFriendlySelfCareAdvice(todayJournal?.mood ?: "Welcome")
            }
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.9f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🍵", fontSize = 28.sp, modifier = Modifier.padding(end = 12.dp))
                    Column {
                        Text(
                            text = "Abantika's Daily Care Advice:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = moodAdvice,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

// --- Menstrual Tracking View ---

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MenstrualView(
    records: List<MenstrualRecord>,
    onAddLog: (String, String?, String, List<String>, String) -> Unit,
    onDeleteLog: (Int) -> Unit
) {
    var showForm by remember { mutableStateOf(false) }

    var startDate by remember { mutableStateOf("") }
    var endDate by remember { mutableStateOf("") }
    var selectedFlow by remember { mutableStateOf("Medium") }
    var notes by remember { mutableStateOf("") }

    val symptomsList = listOf("Cramps", "Headache", "Mood swings", "Fatigue", "Bloating", "Backache")
    val selectedSymptoms = remember { mutableStateListOf<String>() }

    val todayFormatted = remember {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        sdf.format(Date())
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Menstrual Logs 🩸",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Button(
                        onClick = {
                            startDate = todayFormatted
                            endDate = ""
                            selectedFlow = "Medium"
                            selectedSymptoms.clear()
                            notes = ""
                            showForm = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = "Add period log", tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Log period", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Track duration, fluid flow, and patterns.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }

        if (records.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("🌸", fontSize = 48.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "It's clean here! No period logged yet.\nClick 'Log Period' to initialize estimates.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.secondary,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            items(records) { record ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("🩸", fontSize = 20.sp)
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Start: ${formatDateForDisplay(record.startDate)}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            if (!record.endDate.isNullOrEmpty()) {
                                Text(
                                    text = "End: ${formatDateForDisplay(record.endDate)}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            } else {
                                Text(
                                    text = "Active Cycle (Ongoing)",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.tertiary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Row(modifier = Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                SuggestionChip(
                                    onClick = {},
                                    label = { Text("Flow: ${record.flowLevel}", fontSize = 10.sp) }
                                )
                                if (record.symptoms.isNotEmpty()) {
                                    val count = record.symptoms.split(",").size
                                    SuggestionChip(
                                        onClick = {},
                                        label = { Text("$count Symptoms", fontSize = 10.sp) }
                                    )
                                }
                            }

                            if (record.notes.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Note: ${record.notes}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        IconButton(onClick = { onDeleteLog(record.id) }) {
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = "Delete period record",
                                tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            }
        }
    }

    // Modal dialog form for logging a period
    if (showForm) {
        Dialog(onDismissRequest = { showForm = false }) {
            Card(
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .padding(18.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Log Period Cycle 🩸",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    // Start Date Output Box
                    OutlinedTextField(
                        value = startDate,
                        onValueChange = { startDate = it },
                        label = { Text("Start Date (yyyy-MM-dd)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = endDate,
                        onValueChange = { endDate = it },
                        label = { Text("End Date (Optional: yyyy-MM-dd)") },
                        placeholder = { Text("Leave blank if ongoing") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Flow control
                    Text("Flow Level", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Light", "Medium", "Heavy").forEach { level ->
                            val isSelected = selectedFlow == level
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.background)
                                    .border(
                                        1.dp,
                                        if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                        RoundedCornerShape(12.dp)
                                    )
                                    .clickable { selectedFlow = level }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    level,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    // Symptoms tags
                    Text("Symptoms experienced", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        symptomsList.forEach { symp ->
                            val isChosen = selectedSymptoms.contains(symp)
                            FilterChip(
                                selected = isChosen,
                                onClick = {
                                    if (isChosen) selectedSymptoms.remove(symp)
                                    else selectedSymptoms.add(symp)
                                },
                                label = { Text(symp, fontSize = 11.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Cycle/Symptom Notes") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showForm = false }) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (startDate.isNotEmpty()) {
                                    onAddLog(
                                        startDate,
                                        endDate.ifEmpty { null },
                                        selectedFlow,
                                        selectedSymptoms.toList(),
                                        notes
                                    )
                                    showForm = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("Save Entry", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// --- Detailed Hydration Tracking View ---

@Composable
fun HydrationView(
    records: List<HydrationRecord>,
    totalDrunk: Int,
    onAddWater: (Int) -> Unit,
    onDeleteRecord: (HydrationRecord) -> Unit
) {
    val context = LocalContext.current
    val progress = (totalDrunk.toFloat() / 2000f).coerceIn(0f, 1f)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiary),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Water Wheel Progress 💧",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    // Progress circular spinner decoration
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(140.dp)) {
                        CircularProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.size(120.dp),
                            color = TealAccent,
                            strokeWidth = 10.dp,
                            trackColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)
                        )
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${(progress * 100).toInt()}%",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "$totalDrunk / 2000 ml",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Target: 2000 ml (8 cups a day) to glow!",
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.82f)
                    )
                }
            }
        }

        // Fast cup indicators
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Quick Drink Water 🥛",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "Small glass (250 ml)" to 250,
                        "Water Bottle (500 ml)" to 500,
                        "Tall Tumbler (750 ml)" to 750
                    ).forEach { (label, amount) ->
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onAddWater(amount) },
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(8.dp)
                                    .fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("💧", fontSize = 20.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    label,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    "+$amount ml",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Water drink logging item list
        item {
            Text(
                text = "Today's Intake Log",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        if (records.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Text(
                        text = "Haven't drunk water yet today. Quick add above! 🥛",
                        fontSize = 12.sp,
                        modifier = Modifier.padding(16.dp),
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        } else {
            items(records) { record ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("💧", fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Drunk ${record.amountMl} ml",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                val format = SimpleDateFormat("HH:mm", Locale.getDefault())
                                Text(
                                    text = format.format(Date(record.timestamp)),
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }

                        IconButton(onClick = { onDeleteRecord(record) }) {
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = "Delete record",
                                tint = MaterialTheme.colorScheme.error.copy(alpha = 0.6f)
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- Personalized Journal View ---

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun JournalView(
    viewModel: CareViewModel
) {
    val history by viewModel.journalHistory.collectAsStateWithLifecycle()
    val selectedDate by viewModel.selectedDate.collectAsStateWithLifecycle()
    
    var searchQuery by remember { mutableStateOf("") }
    var selectedMoodFilter by remember { mutableStateOf<String?>(null) }
    var selectedStickerFilter by remember { mutableStateOf<String?>(null) }
    
    var calendarMonth by remember { mutableStateOf(Calendar.getInstance()) }
    
    var showDialog by remember { mutableStateOf(false) }
    var editingEntry by remember { mutableStateOf<MoodJournal?>(null) }
    
    var isCalendarFilterActive by remember { mutableStateOf(true) }

    val filteredHistory = remember(history, searchQuery, selectedMoodFilter, selectedStickerFilter, selectedDate, isCalendarFilterActive) {
        history.filter { entry ->
            val matchesSearch = searchQuery.isEmpty() || 
                    entry.title.contains(searchQuery, ignoreCase = true) || 
                    entry.note.contains(searchQuery, ignoreCase = true)
            
            val matchesMood = selectedMoodFilter == null || entry.mood == selectedMoodFilter
            
            val matchesSticker = selectedStickerFilter == null || 
                    entry.stickers.split(",").contains(selectedStickerFilter)
            
            val matchesDate = !isCalendarFilterActive || entry.date == selectedDate
            
            matchesSearch && matchesMood && matchesSticker && matchesDate
        }
    }

    val groupedEntries = remember(filteredHistory) {
        filteredHistory.groupBy { it.date }.toList().sortedByDescending { it.first }
    }

    val entryDates = remember(history) {
        history.map { it.date }.toSet()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Section 1: Notebook Header
            item {
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "My Personal Diary 📔",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Capture your thoughts, mood & memories",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.secondaryContainer)
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "${history.size} Logs",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }

            // Section 2: Interactive Monthly Calendar
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.tertiaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val monthYearFmt = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
                            Text(
                                text = monthYearFmt.format(calendarMonth.time),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                IconButton(
                                    onClick = {
                                        val prev = calendarMonth.clone() as Calendar
                                        prev.add(Calendar.MONTH, -1)
                                        calendarMonth = prev
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.KeyboardArrowLeft,
                                        contentDescription = "Previous Month",
                                        tint = MaterialTheme.colorScheme.onTertiaryContainer,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        val next = calendarMonth.clone() as Calendar
                                        next.add(Calendar.MONTH, 1)
                                        calendarMonth = next
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.KeyboardArrowRight,
                                        contentDescription = "Next Month",
                                        tint = MaterialTheme.colorScheme.onTertiaryContainer,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        val weekdays = listOf("Su", "Mo", "Tu", "We", "Th", "Fr", "Sa")
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            weekdays.forEach { day ->
                                Text(
                                    text = day,
                                    modifier = Modifier.weight(1f),
                                    textAlign = TextAlign.Center,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        val days = remember(calendarMonth) { getDaysInMonth(calendarMonth) }
                        val dbSdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                        
                        val rows = days.chunked(7)
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            rows.forEach { weekRow ->
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    weekRow.forEach { date ->
                                        if (date == null) {
                                            Spacer(modifier = Modifier.weight(1f).aspectRatio(1f))
                                        } else {
                                            val dateStr = dbSdf.format(date)
                                            val isSelected = isCalendarFilterActive && dateStr == selectedDate
                                            val hasEntries = entryDates.contains(dateStr)
                                            val cal = Calendar.getInstance().apply { time = date }
                                            val dayNum = cal.get(Calendar.DAY_OF_MONTH)

                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .aspectRatio(1f)
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .background(
                                                        when {
                                                            isSelected -> MaterialTheme.colorScheme.tertiaryContainer
                                                            hasEntries -> MaterialTheme.colorScheme.surfaceVariant
                                                            else -> Color.Transparent
                                                        }
                                                    )
                                                    .clickable {
                                                        viewModel.setSelectedDate(dateStr)
                                                        isCalendarFilterActive = true
                                                    }
                                                    .padding(2.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Column(
                                                    horizontalAlignment = Alignment.CenterHorizontally,
                                                    verticalArrangement = Arrangement.Center
                                                ) {
                                                    Text(
                                                        text = dayNum.toString(),
                                                        fontSize = 11.sp,
                                                        fontWeight = if (isSelected || hasEntries) FontWeight.Bold else FontWeight.Medium,
                                                        color = if (isSelected) MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onSurface
                                                    )
                                                    if (hasEntries && !isSelected) {
                                                        Box(
                                                            modifier = Modifier
                                                                .size(4.dp)
                                                                .clip(CircleShape)
                                                                .background(MaterialTheme.colorScheme.tertiary)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    if (weekRow.size < 7) {
                                        for (i in 0 until (7 - weekRow.size)) {
                                            Spacer(modifier = Modifier.weight(1f).aspectRatio(1f))
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isCalendarFilterActive) {
                                    "Logs for: ${formatDateForDisplay(selectedDate)}"
                                } else {
                                    "Showing all entries"
                                },
                                fontSize = 11.sp,
                                fontStyle = FontStyle.Italic,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )

                            TextButton(
                                onClick = { isCalendarFilterActive = !isCalendarFilterActive },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (isCalendarFilterActive) "Show All Days" else "Filter Selected Day",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.tertiary
                                )
                            }
                        }
                    }
                }
            }

            // Section 3: Live Filters and Search Bar
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search title, memories, notes...", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            textStyle = LocalTextStyle.current.copy(fontSize = 13.sp),
                            leadingIcon = {
                                Icon(Icons.Filled.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(18.dp)) {
                                        Icon(Icons.Filled.Clear, contentDescription = "Clear text", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline
                            )
                        )

                        // Mood filters
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "Filter by Mood:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val isAllMoodsSelected = selectedMoodFilter == null
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (isAllMoodsSelected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                                        .border(1.dp, if (isAllMoodsSelected) MaterialTheme.colorScheme.primary else Color.Transparent, RoundedCornerShape(12.dp))
                                        .clickable { selectedMoodFilter = null }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text("All Moods 🎭", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isAllMoodsSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                                }

                                val availableMoods = listOf("Happy", "Excited", "Calm", "Grateful", "Motivated", "Tired", "Sad", "Anxious", "Stressed", "Angry")
                                availableMoods.forEach { mood ->
                                    val isSelected = selectedMoodFilter == mood
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(if (isSelected) getMoodColor(mood) else getMoodColor(mood).copy(alpha = 0.15f))
                                            .border(1.dp, if (isSelected) MaterialTheme.colorScheme.onSurface else Color.Transparent, RoundedCornerShape(12.dp))
                                            .clickable { selectedMoodFilter = if (isSelected) null else mood }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(getMoodEmoji(mood), fontSize = 12.sp)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(mood, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                        }
                                    }
                                }
                            }
                        }

                        // Sticker filters
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "Filter by Sticker:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val isAllStickersSelected = selectedStickerFilter == null
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (isAllStickersSelected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                                        .border(1.dp, if (isAllStickersSelected) MaterialTheme.colorScheme.primary else Color.Transparent, RoundedCornerShape(12.dp))
                                        .clickable { selectedStickerFilter = null }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text("All Stickers ⭐", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isAllStickersSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                                }

                                val stickerOptions = listOf("🌸", "💖", "✨", "🍵", "🧸", "🎈", "🐱", "🌈", "☀️", "🍀")
                                stickerOptions.forEach { sticker ->
                                    val isSelected = selectedStickerFilter == sticker
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(if (isSelected) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                                            .border(1.dp, if (isSelected) MaterialTheme.colorScheme.tertiary else Color.Transparent, RoundedCornerShape(12.dp))
                                            .clickable { selectedStickerFilter = if (isSelected) null else sticker }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(sticker, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Section 4: History Logs grouped by Date
            if (groupedEntries.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(
                            modifier = Modifier.padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text("📝", fontSize = 42.sp)
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "No matching diary logs found.",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Try clearing filters or click the '+' button below to record a new beautiful diary memory!",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                groupedEntries.forEach { (dateStr, entries) ->
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 10.dp, bottom = 4.dp)
                        ) {
                            Text(
                                text = formatDateForDisplay(dateStr),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.secondaryContainer)
                                    .padding(horizontal = 12.dp, vertical = 4.dp)
                            )
                        }
                    }

                    items(entries, key = { it.id }) { entry ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    editingEntry = entry
                                    showDialog = true
                                },
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = getMoodColor(entry.mood).copy(alpha = 0.95f)),
                            border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(getMoodEmoji(entry.mood), fontSize = 26.sp)
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = if (entry.title.isNotEmpty()) entry.title else "${entry.mood} Reflection",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            val timeStr = formatTimeForDisplay(entry.timestamp)
                                            val editedStr = if (entry.lastEdited > entry.timestamp + 5000) " • Edited" else ""
                                            Text(
                                                text = "$timeStr$editedStr",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                        IconButton(
                                            onClick = {
                                                editingEntry = entry
                                                showDialog = true
                                            },
                                            modifier = Modifier.size(30.dp)
                                        ) {
                                            Icon(Icons.Filled.Edit, contentDescription = "Edit entry", tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f), modifier = Modifier.size(16.dp))
                                        }
                                        val context = LocalContext.current
                                        IconButton(
                                            onClick = {
                                                viewModel.duplicateJournal(entry)
                                                Toast.makeText(context, "Log duplicated successfully! 📝", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.size(30.dp)
                                        ) {
                                            Icon(Icons.Filled.ContentCopy, contentDescription = "Duplicate entry", tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f), modifier = Modifier.size(16.dp))
                                        }
                                        IconButton(
                                            onClick = {
                                                viewModel.deleteJournal(entry.id)
                                                Toast.makeText(context, "Diary log deleted.", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.size(30.dp)
                                        ) {
                                            Icon(Icons.Filled.Delete, contentDescription = "Delete entry", tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f), modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(1.dp)
                                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.6f))
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Text(
                                    text = entry.note,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    lineHeight = 18.sp,
                                    fontWeight = FontWeight.Medium
                                )

                                if (entry.stickers.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Row(
                                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        entry.stickers.split(",").forEach { sticker ->
                                            if (sticker.trim().isNotEmpty()) {
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.45f))
                                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                                ) {
                                                    Text(sticker, fontSize = 11.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        FloatingActionButton(
            onClick = {
                editingEntry = null
                showDialog = true
            },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .size(56.dp),
            containerColor = MaterialTheme.colorScheme.tertiaryContainer,
            contentColor = MaterialTheme.colorScheme.tertiary,
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = "New diary log", modifier = Modifier.size(28.dp))
        }
    }

    if (showDialog) {
        DiaryEntryDialog(
            entry = editingEntry,
            defaultDate = selectedDate,
            onDismiss = { showDialog = false },
            onSave = { id, title, note, mood, date, stickers ->
                viewModel.saveJournalEntry(id, title, note, mood, date, stickers)
                showDialog = false
            }
        )
    }
}

fun getDaysInMonth(monthCalendar: Calendar): List<Date?> {
    val cal = monthCalendar.clone() as Calendar
    cal.set(Calendar.DAY_OF_MONTH, 1)
    val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
    
    val days = mutableListOf<Date?>()
    val offset = firstDayOfWeek - 1
    for (i in 0 until offset) {
        days.add(null)
    }
    
    val maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    for (i in 1..maxDay) {
        cal.set(Calendar.DAY_OF_MONTH, i)
        days.add(cal.time)
    }
    return days
}

fun formatTimeForDisplay(timestamp: Long): String {
    val sdf = SimpleDateFormat("h:mm a", Locale.getDefault())
    return sdf.format(Date(timestamp))
}

@Composable
fun DiaryEntryDialog(
    entry: MoodJournal?,
    defaultDate: String,
    onDismiss: () -> Unit,
    onSave: (id: Int, title: String, note: String, mood: String, date: String, stickers: List<String>) -> Unit
) {
    var title by remember { mutableStateOf(entry?.title ?: "") }
    var note by remember { mutableStateOf(entry?.note ?: "") }
    var mood by remember { mutableStateOf(entry?.mood ?: "Happy") }
    var dateString by remember { mutableStateOf(entry?.date ?: defaultDate) }
    
    val selectedStickers = remember { mutableStateListOf<String>() }
    
    LaunchedEffect(entry) {
        if (entry != null) {
            selectedStickers.clear()
            if (entry.stickers.isNotEmpty()) {
                selectedStickers.addAll(entry.stickers.split(","))
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .wrapContentHeight(),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.5.dp, getMoodColor(mood))
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = if (entry == null) "Write in My Diary 📔" else "Edit Diary Log ✏️",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 4.dp)
                )

                OutlinedTextField(
                    value = dateString,
                    onValueChange = { dateString = it },
                    label = { Text("Log Date (yyyy-MM-dd)", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    textStyle = LocalTextStyle.current.copy(fontSize = 12.sp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title (Optional)", fontSize = 11.sp) },
                    placeholder = { Text("What happened today?", fontSize = 12.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    textStyle = LocalTextStyle.current.copy(fontSize = 13.sp),
                    singleLine = true
                )

                Text("Select your primary feeling:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val moods = listOf("Happy", "Excited", "Calm", "Grateful", "Motivated", "Tired", "Sad", "Anxious", "Stressed", "Angry")
                    moods.forEach { m ->
                        val isSelected = mood == m
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) getMoodColor(m) else getMoodColor(m).copy(alpha = 0.15f))
                                .border(1.dp, if (isSelected) MaterialTheme.colorScheme.onSurface else Color.Transparent, RoundedCornerShape(12.dp))
                                .clickable { mood = m }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(getMoodEmoji(m), fontSize = 13.sp)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(m, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Diary Memories & Thoughts", fontSize = 11.sp) },
                    placeholder = { Text("Write about your thoughts, emotions, memories, people...", fontSize = 12.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    textStyle = LocalTextStyle.current.copy(fontSize = 13.sp),
                    minLines = 4,
                    maxLines = 8,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = getMoodColor(mood),
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    )
                )

                Text("Attach cute mood stickers:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val stickerOptions = listOf("🌸", "💖", "✨", "🍵", "📖", "📝", "🏡", "📅", "🧸", "🍦", "🍪", "🎈", "🐱", "🐶", "🌈", "☀️", "🌧️", "❄️", "🍀", "💡", "🔑", "🎁")
                    stickerOptions.forEach { sticker ->
                        val isAttached = selectedStickers.contains(sticker)
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isAttached) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                                .border(1.5.dp, if (isAttached) MaterialTheme.colorScheme.tertiary else Color.Transparent, RoundedCornerShape(10.dp))
                                .clickable {
                                    if (isAttached) selectedStickers.remove(sticker)
                                    else selectedStickers.add(sticker)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(sticker, fontSize = 16.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (note.trim().isNotEmpty()) {
                                onSave(entry?.id ?: 0, title, note, mood, dateString, selectedStickers.toList())
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer, contentColor = MaterialTheme.colorScheme.tertiary),
                        shape = RoundedCornerShape(14.dp),
                        enabled = note.trim().isNotEmpty()
                    ) {
                        Text("Save Entry", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// --- Settings, Custom Alarms, and Cloud JSON Sync Sheet Dialog ---

@Composable
fun SettingsDialog(
    viewModel: CareViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()

    val exportLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        uri?.let { viewModel.exportToFile(context, it) }
    }

    val importLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { viewModel.importFromFile(context, it) }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Top Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "App Settings ⚙️",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Close dialog",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                // Privacy Indicator Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.6f)),
                    border = BorderStroke(1.dp, TealAccent.copy(alpha = 0.3f))
                ) {
                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🛡️", fontSize = 24.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "100% Data Privacy Guaranteed. All your cycle, and diary logs are fully encrypted locally on your device.",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                // App Color Theme Section
                Text("Personalize App Color Theme 🎨", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                    text = "Pick from 16 beautiful custom color palettes. Your choice is fully private and completely independent of system light/dark mode.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.secondary
                )

                val selectedThemeIndex by viewModel.selectedThemeIndex.collectAsStateWithLifecycle()

                // List the themes in a neat vertically stacked list of cards
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    com.example.ui.theme.AppThemesList.forEachIndexed { index, config ->
                        val isSelected = selectedThemeIndex == index
                        Card(
                            onClick = { viewModel.setSelectedThemeIndex(index) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) config.colorScheme.primary.copy(alpha = 0.15f) else config.colorScheme.surface
                            ),
                            border = BorderStroke(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) config.colorScheme.primary else config.colorScheme.onSurface.copy(alpha = 0.1f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = { viewModel.setSelectedThemeIndex(index) },
                                        colors = RadioButtonDefaults.colors(
                                            selectedColor = config.colorScheme.primary,
                                            unselectedColor = config.colorScheme.onSurface.copy(alpha = 0.6f)
                                        )
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = config.name,
                                        fontSize = 13.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                // Preview circle bubbles for the 4 colors of the palette
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    listOf(
                                        config.colorScheme.primary,
                                        config.colorScheme.secondary,
                                        config.colorScheme.surfaceVariant,
                                        config.colorScheme.background
                                    ).forEach { color ->
                                        Box(
                                            modifier = Modifier
                                                .size(16.dp)
                                                .clip(CircleShape)
                                                .background(color)
                                                .border(0.5.dp, Color.Gray, CircleShape)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                // Backup Section
                Text("Backup and Restore 💾", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                    text = "Export your local data to a JSON file, or restore from a previously saved JSON file.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.secondary
                )

                Button(
                    onClick = {
                        val timestamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.getDefault()).format(java.util.Date())
                        exportLauncher.launch("CareAppBackup_$timestamp.json")
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("Export Data to File 💾", color = MaterialTheme.colorScheme.onPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        importLauncher.launch(arrayOf("application/json"))
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Text("Restore from JSON File 📂", color = MaterialTheme.colorScheme.onSecondary, fontWeight = FontWeight.Bold)
                }

                // Sync status indicator
                when (syncState) {
                    is SyncStatus.Success -> {
                        Text(
                            text = (syncState as SyncStatus.Success).msg,
                            color = TealAccent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                    is SyncStatus.Error -> {
                        Text(
                            text = (syncState as SyncStatus.Error).err,
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                    SyncStatus.Syncing -> {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp).align(Alignment.CenterHorizontally))
                    }
                    else -> {}
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RemindersDialog(
    reminders: List<CustomReminder>,
    viewModel: CareViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    var reminderTitle by remember { mutableStateOf("") }
    var reminderMsg by remember { mutableStateOf("") }
    var reminderTime by remember { mutableStateOf("09:00") }

    val daysList = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
    val selectedDays = remember { mutableStateListOf<String>() }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f)
                .padding(vertical = 12.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Top Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "My Reminders ⏰",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Filled.Close, contentDescription = "Close dialog")
                    }
                }

                // Custom Reminder Panel
                Text("Create New Reminder", fontWeight = FontWeight.Bold, fontSize = 14.sp)

                OutlinedTextField(
                    value = reminderTitle,
                    onValueChange = { reminderTitle = it },
                    label = { Text("Reminder Title") },
                    placeholder = { Text("E.g. Time for Water 🥤") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = reminderMsg,
                    onValueChange = { reminderMsg = it },
                    label = { Text("Reminder Message") },
                    placeholder = { Text("Time for your morning hydration goals!") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = reminderTime,
                    onValueChange = { reminderTime = it },
                    label = { Text("Trigger Time (HH:mm)") },
                    placeholder = { Text("09:00") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Select Days layout
                Text("Trigger Days", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    daysList.forEach { day ->
                        val isChosen = selectedDays.contains(day)
                        FilterChip(
                            selected = isChosen,
                            onClick = {
                                if (isChosen) selectedDays.remove(day)
                                else selectedDays.add(day)
                            },
                            label = { Text(day, fontSize = 11.sp) }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            viewModel.triggerInstantCheckInNotification()
                            Toast.makeText(context, "Immediate System Notification simulated!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    ) {
                        Text("Test Alert 🔔", color = MaterialTheme.colorScheme.onSurface, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            if (reminderTitle.isNotEmpty() && reminderMsg.isNotEmpty() && reminderTime.isNotEmpty()) {
                                viewModel.saveReminder(
                                    reminderTitle,
                                    reminderMsg,
                                    reminderTime,
                                    selectedDays.toList().ifEmpty { daysList }
                                )
                                reminderTitle = ""
                                reminderMsg = ""
                                selectedDays.clear()
                                Toast.makeText(context, "Alarm Configured! ⏰", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        enabled = reminderTitle.isNotEmpty() && reminderTime.isNotEmpty()
                    ) {
                        Text("Save", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                // Active Reminders List
                if (reminders.isNotEmpty()) {
                    Text("Configured Alarms", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    reminders.forEach { reminder ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(reminder.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(reminder.message, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                                    Text("Time: ${reminder.time} | Scheduled", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                                Switch(
                                    checked = reminder.isEnabled,
                                    onCheckedChange = { viewModel.toggleReminder(reminder) }
                                )
                                IconButton(onClick = { viewModel.deleteReminder(reminder.id) }) {
                                    Icon(imageVector = Icons.Filled.Delete, contentDescription = "Delete alarm", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                } else {
                    Text(
                        text = "No reminders setup yet.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }
    }
}

@Composable
fun ShoppingView(
    items: List<ShoppingItem>,
    viewModel: CareViewModel
) {
    var showDialog by remember { mutableStateOf(false) }
    var selectedCategory by remember { mutableStateOf("Save for Later") }
    val categories = listOf("Save for Later", "Urgent Need", "For Him", "Dream Cart")

    val filteredItems = items.filter { it.category == selectedCategory }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(10.dp))
            // Category Tabs
            ScrollableTabRow(
                selectedTabIndex = categories.indexOf(selectedCategory),
                containerColor = Color.Transparent,
                edgePadding = 0.dp,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[categories.indexOf(selectedCategory)]),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            ) {
                categories.forEach { category ->
                    Tab(
                        selected = selectedCategory == category,
                        onClick = { selectedCategory = category },
                        text = {
                            Text(
                                text = category,
                                fontSize = 12.sp,
                                fontWeight = if (selectedCategory == category) FontWeight.Bold else FontWeight.Medium,
                                color = if (selectedCategory == category) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    )
                }
            }

            if (filteredItems.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🛍️", fontSize = 48.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Your cart is empty",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredItems, key = { it.id }) { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                // Simple image placeholder if URL exists
                                if (item.imageUrl.isNotEmpty()) {
                                    AsyncImage(
                                        model = item.imageUrl,
                                        contentDescription = "Preview Image",
                                        modifier = Modifier
                                            .size(64.dp)
                                            .clip(RoundedCornerShape(8.dp)),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(64.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MaterialTheme.colorScheme.secondaryContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("🛍️", fontSize = 24.sp)
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.title.ifEmpty { "New Item" },
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    if (item.url.isNotEmpty()) {
                                        Text(
                                            text = item.url,
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.primary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    if (item.note.isNotEmpty()) {
                                        Text(
                                            text = item.note,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                IconButton(onClick = { viewModel.deleteShoppingItem(item.id) }) {
                                    Icon(imageVector = Icons.Filled.Delete, contentDescription = "Remove", tint = MaterialTheme.colorScheme.outlineVariant)
                                }
                            }
                        }
                    }
                    item {
                        Spacer(modifier = Modifier.height(80.dp))
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { showDialog = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .size(56.dp),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = "Add Item", modifier = Modifier.size(28.dp))
        }
    }

    if (showDialog) {
        var newTitle by remember { mutableStateOf("") }
        var newUrl by remember { mutableStateOf("") }
        var newNote by remember { mutableStateOf("") }
        var newImageUrl by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { showDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Add to $selectedCategory 🛒",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        label = { Text("Item Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newUrl,
                        onValueChange = { newUrl = it },
                        label = { Text("Link (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newImageUrl,
                        onValueChange = { newImageUrl = it },
                        label = { Text("Image URL (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newNote,
                        onValueChange = { newNote = it },
                        label = { Text("Notes / Details") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showDialog = false }) {
                            Text("Cancel")
                        }
                        Button(
                            onClick = {
                                viewModel.saveShoppingItem(
                                    category = selectedCategory,
                                    url = newUrl,
                                    title = newTitle,
                                    note = newNote,
                                    imageUrl = newImageUrl
                                )
                                showDialog = false
                            },
                            enabled = newTitle.isNotEmpty()
                        ) {
                            Text("Save Item")
                        }
                    }
                }
            }
        }
    }
}

// --- Helpers & Visual Color Maps ---

fun getMoodEmoji(mood: String): String {
    return when (mood) {
        "Excited" -> "💖"
        "Happy" -> "😊"
        "Calm" -> "🧘"
        "Tired" -> "🥱"
        "Sad" -> "😢"
        "Anxious" -> "🥺"
        "Stressed" -> "🤯"
        "Grateful" -> "🙏"
        "Motivated" -> "🎯"
        "Angry" -> "😡"
        else -> "✨"
    }
}

@Composable
fun getMoodColor(mood: String): Color {
    val baseColor = when (mood) {
        "Excited" -> MaterialTheme.colorScheme.primary
        "Happy" -> MaterialTheme.colorScheme.secondaryContainer
        "Calm" -> MaterialTheme.colorScheme.tertiary
        "Tired" -> MaterialTheme.colorScheme.secondary
        "Sad" -> MaterialTheme.colorScheme.surfaceVariant
        "Anxious" -> MaterialTheme.colorScheme.primaryContainer
        "Stressed" -> MaterialTheme.colorScheme.tertiaryContainer
        "Grateful" -> MaterialTheme.colorScheme.primaryContainer
        "Motivated" -> MaterialTheme.colorScheme.secondaryContainer
        "Angry" -> MaterialTheme.colorScheme.tertiaryContainer
        else -> MaterialTheme.colorScheme.primary
    }
    return baseColor
}

// Custom friendly Advice engine
fun getFriendlySelfCareAdvice(mood: String): String {
    return when (mood) {
        "Excited" -> "How exciting! Let's write down what brought this magic so you can relive it whenever you want! 💖"
        "Happy" -> "You have a beautiful smile! Keep radiating. Spend today sharing this warmth with someone you love or watering plants. 🌸"
        "Calm" -> "Serenity is a superpower. Meditate, close your eyes, and take 5 deep slow breaths to stretch this beautiful morning! 🧘"
        "Tired" -> "It's completely okay to pause. Prepare a warm mug of lavender tea, curl up, and take a 20 minute sweet power nap. 🥱"
        "Sad" -> "Your feelings are valid. Let those tears release tension if they want to. Today is a great day for warm socks, sweet music, and cocoa. 😢"
        "Anxious" -> "Breathe in for 4 seconds, hold for 4, release for 4. Ground yourself by logging a refreshing cup of water. You are completely safe! 🥺"
        "Stressed" -> "Let's lift those heavy shoulders. Write down everything that details your stress in journals to move it out of your cute head! 🤯"
        else -> "Hey Abantika! Have you had enough water to glow? Let's take a peaceful moment to record your daily mood, period status, or hydration level! ✨"
    }
}

fun formatDisplayDate(dateStr: String): String {
    return try {
        val inputFmt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val outputFmt = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault())
        val date = inputFmt.parse(dateStr) ?: return dateStr
        outputFmt.format(date)
    } catch (e: Exception) {
        dateStr
    }
}

fun formatDateForDisplay(dateStr: String): String {
    return try {
        val inputFmt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val outputFmt = SimpleDateFormat("MMMM d, yyyy", Locale.getDefault())
        val date = inputFmt.parse(dateStr) ?: return dateStr
        outputFmt.format(date)
    } catch (e: Exception) {
        dateStr
    }
}

fun formatDateToDisplayMonthOnly(dateStr: String): String {
    return try {
        val inputFmt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val outputFmt = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
        val date = inputFmt.parse(dateStr) ?: return dateStr
        outputFmt.format(date)
    } catch (e: Exception) {
        dateStr
    }
}

// Period Insight Predictions Calculator
fun calculateCycleStats(records: List<MenstrualRecord>): CycleStats? {
    if (records.isEmpty()) return null
    val format = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val latestRecord = records.maxByOrNull { it.startDate } ?: return null
    return try {
        val startDate = format.parse(latestRecord.startDate) ?: return null

        // Add 28 days for prediction
        val nextPeriodCalendar = Calendar.getInstance().apply {
            time = startDate
            add(Calendar.DAY_OF_YEAR, 28)
        }
        val nextPeriodDateString = format.format(nextPeriodCalendar.time)

        // Ovulation is on average start date + 14 days
        val ovulationCalendar = Calendar.getInstance().apply {
            time = startDate
            add(Calendar.DAY_OF_YEAR, 14)
        }
        val ovulationDateString = format.format(ovulationCalendar.time)

        // Fertile window days start date + 12 days to start date + 17 days
        val fertileStartCalendar = Calendar.getInstance().apply {
            time = startDate
            add(Calendar.DAY_OF_YEAR, 12)
        }
        val fertileEndCalendar = Calendar.getInstance().apply {
            time = startDate
            add(Calendar.DAY_OF_YEAR, 17)
        }

        // Days remaining
        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val nextPeriodDayStart = Calendar.getInstance().apply {
            time = nextPeriodCalendar.time
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val diffMs = nextPeriodDayStart.timeInMillis - today.timeInMillis
        val diffDays = (diffMs / (1000 * 60 * 60 * 24)).toInt()

        // Phase estimation
        val startCalendar = Calendar.getInstance().apply {
            time = startDate
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val durationMsSinceStart = today.timeInMillis - startCalendar.timeInMillis
        val daysSinceStart = (durationMsSinceStart / (1000 * 60 * 60 * 24)).toInt()

        val phase = when {
            daysSinceStart in 0..5 -> "Menstruation Cycle 🩸"
            daysSinceStart in 6..11 -> "Follicular Phase 🌱"
            daysSinceStart in 12..17 -> "Fertile Window ✨"
            daysSinceStart == 14 -> "Ovulation Day 🌸"
            else -> "Luteal Phase 🌾"
        }

        CycleStats(
            lastStartDate = latestRecord.startDate,
            nextStartDate = nextPeriodDateString,
            ovulationDate = ovulationDateString,
            fertileRange = "${formatDateForDisplay(format.format(fertileStartCalendar.time))} - ${formatDateForDisplay(format.format(fertileEndCalendar.time))}",
            daysUntilSub = if (diffDays < 0) 28 + diffDays else diffDays,
            currentPhase = phase
        )
    } catch (e: Exception) {
        null
    }
}

data class CycleStats(
    val lastStartDate: String,
    val nextStartDate: String,
    val ovulationDate: String,
    val fertileRange: String,
    val daysUntilSub: Int,
    val currentPhase: String
)
