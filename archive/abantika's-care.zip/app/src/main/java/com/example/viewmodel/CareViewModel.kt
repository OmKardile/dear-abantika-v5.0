package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.receiver.NotificationScheduler
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class CareViewModel(application: Application, private val repository: CareRepository) : AndroidViewModel(application) {

    private val context: Context get() = getApplication()
    val backupManager = BackupManager(repository)

    private val prefs = application.getSharedPreferences("care_app_prefs", Context.MODE_PRIVATE)
    private val _selectedThemeIndex = MutableStateFlow(prefs.getInt("selected_theme_index", 0))
    val selectedThemeIndex: StateFlow<Int> = _selectedThemeIndex.asStateFlow()

    fun setSelectedThemeIndex(index: Int) {
        prefs.edit().putInt("selected_theme_index", index).apply()
        _selectedThemeIndex.value = index
    }

    // Current selected date for tracking ("yyyy-MM-dd")
    private val _selectedDate = MutableStateFlow(getTodayDateString())
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }

    fun setSelectedDate(date: String) {
        _selectedDate.value = date
    }

    // --- State Streams ---

    val hydrationHistory: StateFlow<List<HydrationRecord>> = repository.allHydration
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val menstrualHistory: StateFlow<List<MenstrualRecord>> = repository.allMenstrual
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val journalHistory: StateFlow<List<MoodJournal>> = repository.allJournals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val remindersList: StateFlow<List<CustomReminder>> = repository.allReminders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filter flows for the selected date
    val todayHydration: StateFlow<List<HydrationRecord>> = _selectedDate
        .flatMapLatest { date -> repository.getHydrationByDate(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todayJournal: StateFlow<MoodJournal?> = _selectedDate
        .flatMapLatest { date ->
            repository.getJournalByDate(date).map { list -> list.firstOrNull() }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val todayJournals: StateFlow<List<MoodJournal>> = _selectedDate
        .flatMapLatest { date -> repository.getJournalByDate(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val shoppingItems: StateFlow<List<ShoppingItem>> = repository.allShoppingItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Actions ---

    fun addWater(amountMl: Int) {
        viewModelScope.launch {
            val record = HydrationRecord(
                date = _selectedDate.value,
                amountMl = amountMl
            )
            repository.insertHydration(record)
        }
    }

    fun deleteWater(record: HydrationRecord) {
        viewModelScope.launch {
            repository.deleteHydrationById(record.id)
        }
    }

    fun addMenstrualLog(startDate: String, endDate: String?, flowLevel: String, symptoms: List<String>, notes: String) {
        viewModelScope.launch {
            val record = MenstrualRecord(
                startDate = startDate,
                endDate = endDate,
                flowLevel = flowLevel,
                symptoms = symptoms.joinToString(","),
                notes = notes
            )
            repository.insertMenstrual(record)
        }
    }

    fun deleteMenstrualLog(id: Int) {
        viewModelScope.launch {
            repository.deleteMenstrualById(id)
        }
    }

    fun saveJournal(mood: String, note: String, activities: List<String>) {
        viewModelScope.launch {
            val existing = repository.getJournalByDateSync(_selectedDate.value)
            val entry = MoodJournal(
                id = existing?.id ?: 0,
                date = _selectedDate.value,
                mood = mood,
                note = note,
                activities = activities.joinToString(","),
                title = "",
                lastEdited = System.currentTimeMillis(),
                stickers = ""
            )
            repository.insertJournal(entry)
        }
    }

    fun saveJournalEntry(id: Int, title: String, note: String, mood: String, date: String, stickers: List<String>) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            // Try to find the original timestamp if editing
            var originalTimestamp = now
            if (id != 0) {
                originalTimestamp = repository.allJournals.first().firstOrNull { it.id == id }?.timestamp ?: now
            }
            val entry = MoodJournal(
                id = id,
                date = date,
                mood = mood,
                note = note,
                activities = "",
                timestamp = originalTimestamp,
                title = title,
                lastEdited = now,
                stickers = stickers.joinToString(",")
            )
            repository.insertJournal(entry)
        }
    }

    fun duplicateJournal(journal: MoodJournal) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val duplicated = journal.copy(
                id = 0, // database auto-gen
                title = if (journal.title.isNotEmpty()) "${journal.title} (Copy)" else "Copy of Entry",
                timestamp = now,
                lastEdited = now
            )
            repository.insertJournal(duplicated)
        }
    }

    fun deleteJournal(id: Int) {
        viewModelScope.launch {
            repository.deleteJournalById(id)
        }
    }

    // --- Shopping Actions ---
    
    fun saveShoppingItem(category: String, url: String, title: String, note: String, imageUrl: String = "") {
        viewModelScope.launch {
            repository.insertShoppingItem(
                ShoppingItem(
                    category = category,
                    url = url,
                    title = title,
                    note = note,
                    imageUrl = imageUrl
                )
            )
        }
    }

    fun deleteShoppingItem(id: Int) {
        viewModelScope.launch {
            repository.deleteShoppingItemById(id)
        }
    }

    // --- Reminders Config ---

    fun saveReminder(title: String, message: String, time: String, days: List<String>) {
        viewModelScope.launch {
            val reminder = CustomReminder(
                title = title,
                message = message,
                time = time,
                daysOfWeek = days.joinToString(","),
                isEnabled = true
            )
            repository.insertReminder(reminder)
            // Schedule the alarm immediately for the next matching time slot
            val randomId = (System.currentTimeMillis() % 10000).toInt()
            NotificationScheduler.scheduleReminder(context, title, message, time, randomId)
        }
    }

    fun toggleReminder(reminder: CustomReminder) {
        viewModelScope.launch {
            val updated = reminder.copy(isEnabled = !reminder.isEnabled)
            repository.insertReminder(updated)
            if (updated.isEnabled) {
                val rId = (updated.id)
                NotificationScheduler.scheduleReminder(context, updated.title, updated.message, updated.time, rId)
            } else {
                NotificationScheduler.cancelReminder(context, updated.id)
            }
        }
    }

    fun deleteReminder(id: Int) {
        viewModelScope.launch {
            repository.deleteReminderById(id)
            NotificationScheduler.cancelReminder(context, id)
        }
    }

    fun triggerInstantCheckInNotification() {
        NotificationScheduler.triggerNotificationImmediately(
            context,
            "Care Self-Check 🌸",
            "Hey Abantika! It's time for some self-love. Log your mood or drink a refreshing cup of water!"
        )
    }

    // --- Simulated Backup/Sync ---

    private val _syncState = MutableStateFlow<SyncStatus>(SyncStatus.Idle)
    val syncState: StateFlow<SyncStatus> = _syncState.asStateFlow()

    fun performExport(): String? {
        var result: String? = null
        viewModelScope.launch {
            _syncState.value = SyncStatus.Syncing
            try {
                result = backupManager.exportDataToJson()
                _syncState.value = SyncStatus.Success("Exported successfully! Keep it private in your secure notes.")
            } catch (e: Exception) {
                _syncState.value = SyncStatus.Error("Failed to export data: ${e.message}")
            }
        }
        return result
    }

    fun performImport(json: String) {
        viewModelScope.launch {
            _syncState.value = SyncStatus.Syncing
            val success = backupManager.importDataFromJson(json)
            if (success) {
                _syncState.value = SyncStatus.Success("Private cloud sync successfully imported across your devices!")
            } else {
                _syncState.value = SyncStatus.Error("Failed to import. Confirm your JSON backup string is valid.")
            }
        }
    }

    fun exportToFile(context: android.content.Context, uri: android.net.Uri) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            _syncState.value = SyncStatus.Syncing
            try {
                val jsonStr = backupManager.exportDataToJson()
                context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                    outputStream.write(jsonStr.toByteArray())
                }
                _syncState.value = SyncStatus.Success("Backup exported to file successfully! 💾")
            } catch (e: Exception) {
                _syncState.value = SyncStatus.Error("Failed to export: ${e.message}")
            }
        }
    }

    fun importFromFile(context: android.content.Context, uri: android.net.Uri) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            _syncState.value = SyncStatus.Syncing
            try {
                val jsonStr = context.contentResolver.openInputStream(uri)?.bufferedReader().use { it?.readText() }
                if (jsonStr != null) {
                    val success = backupManager.importDataFromJson(jsonStr)
                    if (success) {
                        _syncState.value = SyncStatus.Success("Backup imported successfully! 🎉")
                    } else {
                        _syncState.value = SyncStatus.Error("Failed to parse or save imported data.")
                    }
                } else {
                    _syncState.value = SyncStatus.Error("Failed to read file content.")
                }
            } catch (e: Exception) {
                _syncState.value = SyncStatus.Error("Failed to import: ${e.message}")
            }
        }
    }

    fun dismissSyncState() {
        _syncState.value = SyncStatus.Idle
    }
}

sealed interface SyncStatus {
    object Idle : SyncStatus
    object Syncing : SyncStatus
    data class Success(val msg: String) : SyncStatus
    data class Error(val err: String) : SyncStatus
}

// Custom ViewModel Factory
class CareViewModelFactory(
    private val application: Application,
    private val repository: CareRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CareViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return CareViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
