package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Pastel Palette
val PastelPink = Color(0xFFFFD1DC)     // Soft Blush
val PastelLavender = Color(0xFFE2D4F7) // Cute Violet
val PastelPeach = Color(0xFFFFE5D9)    // Sweet Cream Peach
val PastelMint = Color(0xFFD4F2E7)     // Soft Water Mint
val PastelBlue = Color(0xFFD0E1FD)     // Calming Azure
val PastelLemon = Color(0xFFFFF4D0)    // Gentle Yellow Sun
val PastelRose = Color(0xFFFFC4C4)     // Stressed Rose Tint

// Dark Core Tones (for high contrast text and dark mode elements)
val SoftDarkBg = Color(0xFF231F20)
val SoftDarkSurface = Color(0xFF2C2728)

val CoralPink = Color(0xFFFF69B4)
val VioletDeep = Color(0xFF7A5C9B)
val TealAccent = Color(0xFF2E8B75)

// Light Theme Palettes
val PrimaryLight = Color(0xFFFF8FA3)   // Bright Rose
val SecondaryLight = Color(0xFF9F86C0) // Soft Lavender Purple
val TertiaryLight = Color(0xFFF7D9C4)  // Butter Peach
val BackgroundLight = Color(0xFFFFF5F7) // Warm Soft Pink Milk
val SurfaceLight = Color(0xFFFFFFFF)    // Crisp white for boxes

// Dark Theme Palettes
val PrimaryDark = Color(0xFFFFB3C1)
val SecondaryDark = Color(0xFFBEA9DF)
val TertiaryDark = Color(0xFFFFD5C2)
val BackgroundDark = Color(0xFF1F1A1B)
val SurfaceDark = Color(0xFF2C2526)
