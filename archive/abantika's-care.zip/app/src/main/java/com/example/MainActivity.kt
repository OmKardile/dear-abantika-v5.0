package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.AppDatabase
import com.example.data.CareRepository
import com.example.ui.screens.CareDashboard
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.CareViewModel
import com.example.viewmodel.CareViewModelFactory

import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val db = AppDatabase.getDatabase(applicationContext)
            val repository = CareRepository(db)
            val factory = CareViewModelFactory(application, repository)
            
            // Retrieve ViewModel using factory
            val viewModel: CareViewModel = viewModel(factory = factory)
            val themeIndex by viewModel.selectedThemeIndex.collectAsState(initial = 0)

            MyApplicationTheme(themeIndex = themeIndex) {
                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {
                    CareDashboard(viewModel = viewModel)
                }
            }
        }
    }
}
