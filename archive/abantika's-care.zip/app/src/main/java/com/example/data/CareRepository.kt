package com.example.data

import kotlinx.coroutines.flow.Flow

class CareRepository(private val db: AppDatabase) {
    // Hydration
    val allHydration: Flow<List<HydrationRecord>> = db.hydrationDao().getAll()
    fun getHydrationByDate(date: String): Flow<List<HydrationRecord>> = db.hydrationDao().getByDate(date)
    suspend fun insertHydration(record: HydrationRecord) = db.hydrationDao().insert(record)
    suspend fun deleteHydrationById(id: Int) = db.hydrationDao().deleteById(id)

    // Menstrual
    val allMenstrual: Flow<List<MenstrualRecord>> = db.menstrualDao().getAll()
    suspend fun insertMenstrual(record: MenstrualRecord) = db.menstrualDao().insert(record)
    suspend fun deleteMenstrualById(id: Int) = db.menstrualDao().deleteById(id)

    // Journals
    val allJournals: Flow<List<MoodJournal>> = db.journalDao().getAll()
    fun getJournalByDate(date: String): Flow<List<MoodJournal>> = db.journalDao().getByDateFlow(date)
    suspend fun getJournalByDateSync(date: String): MoodJournal? = db.journalDao().getByDate(date)
    suspend fun insertJournal(journal: MoodJournal) = db.journalDao().insert(journal)
    suspend fun deleteJournalById(id: Int) = db.journalDao().deleteById(id)

    // Reminders
    val allReminders: Flow<List<CustomReminder>> = db.reminderDao().getAll()
    suspend fun getActiveReminders(): List<CustomReminder> = db.reminderDao().getActiveReminders()
    suspend fun insertReminder(reminder: CustomReminder) = db.reminderDao().insert(reminder)
    suspend fun deleteReminderById(id: Int) = db.reminderDao().deleteById(id)

    // Shopping
    val allShoppingItems: Flow<List<ShoppingItem>> = db.shoppingDao().getAll()
    suspend fun insertShoppingItem(item: ShoppingItem) = db.shoppingDao().insert(item)
    suspend fun deleteShoppingItemById(id: Int) = db.shoppingDao().deleteById(id)
}
