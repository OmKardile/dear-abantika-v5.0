package com.example.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Define a data structure to hold metadata and color schemes for each of the 15 themes
data class AppThemeConfig(
    val name: String,
    val isDark: Boolean,
    val colorScheme: ColorScheme
)

// The 15 beautiful independent color themes requested by the user
val AppThemesList = listOf(
    // Theme 0: Classic Black & White (Default)
    AppThemeConfig(
        name = "Classic Mono Noir 🖤",
        isDark = false,
        colorScheme = lightColorScheme(
            primary = Color.Black,
            secondary = Color(0xFF1A1A1A),
            tertiary = Color(0xFF333333),
            background = Color.White,
            surface = Color.White,
            surfaceVariant = Color(0xFFF5F5F5),
            onPrimary = Color.White,
            onSecondary = Color.White,
            onTertiary = Color.White,
            onBackground = Color.Black,
            onSurface = Color.Black,
            onSurfaceVariant = Color.Black,
            primaryContainer = Color(0xFFEBEBEB),
            onPrimaryContainer = Color.Black,
            secondaryContainer = Color(0xFFE0E0E0),
            onSecondaryContainer = Color.Black,
            outline = Color.Black,
            outlineVariant = Color(0xFFCCCCCC)
        )
    ),
    // Theme 1: Lavender & Mint (Palette 1)
    AppThemeConfig(
        name = "Lavender & Mint 🌸",
        isDark = false,
        colorScheme = lightColorScheme(
            primary = Color(0xFF9FA1FF),
            secondary = Color(0xFFB5BAFF),
            tertiary = Color(0xFFAEE2FF),
            background = Color(0xFFF5F6FA),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFD9F9DF), // Soft Mint Green
            onPrimary = Color.Black,
            onSecondary = Color.Black,
            onTertiary = Color.Black,
            onBackground = Color.Black,
            onSurface = Color.Black,
            onSurfaceVariant = Color.Black,
            primaryContainer = Color(0xFFE2FFDF),
            onPrimaryContainer = Color.Black,
            secondaryContainer = Color(0xFFB5BAFF),
            onSecondaryContainer = Color.Black,
            outline = Color(0xFF9FA1FF),
            outlineVariant = Color(0xFFB5BAFF)
        )
    ),
    // Theme 2: Sky & Aqua (Palette 2)
    AppThemeConfig(
        name = "Sky & Aqua 🌊",
        isDark = false,
        colorScheme = lightColorScheme(
            primary = Color(0xFF687EFF),
            secondary = Color(0xFF80B3FF),
            tertiary = Color(0xFF98E4FF),
            background = Color(0xFFF0F5FA),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFB6FFFA),
            onPrimary = Color.White,
            onSecondary = Color.Black,
            onTertiary = Color.Black,
            onBackground = Color.Black,
            onSurface = Color.Black,
            onSurfaceVariant = Color.Black,
            primaryContainer = Color(0xFF98E4FF),
            onPrimaryContainer = Color.Black,
            secondaryContainer = Color(0xFF80B3FF),
            onSecondaryContainer = Color.Black,
            outline = Color(0xFF687EFF),
            outlineVariant = Color(0xFF80B3FF)
        )
    ),
    // Theme 3: Deep Berry Wine (Palette 3)
    AppThemeConfig(
        name = "Deep Berry Wine 🍷",
        isDark = true,
        colorScheme = darkColorScheme(
            primary = Color(0xFFEF88AD),
            secondary = Color(0xFFA53860),
            tertiary = Color(0xFF670D2F),
            background = Color(0xFF1E030D),
            surface = Color(0xFF3A0519),
            surfaceVariant = Color(0xFF530925),
            onPrimary = Color.Black,
            onSecondary = Color.White,
            onTertiary = Color.White,
            onBackground = Color.White,
            onSurface = Color.White,
            onSurfaceVariant = Color.White,
            primaryContainer = Color(0xFFEF88AD),
            onPrimaryContainer = Color.Black,
            secondaryContainer = Color(0xFFA53860),
            onSecondaryContainer = Color.White,
            outline = Color(0xFFEF88AD),
            outlineVariant = Color(0xFFA53860)
        )
    ),
    // Theme 4: Cozy Rose Cream (Palette 4)
    AppThemeConfig(
        name = "Cozy Rose Cream 🩰",
        isDark = false,
        colorScheme = lightColorScheme(
            primary = Color(0xFFF2BED1),
            secondary = Color(0xFFFDCEDF),
            tertiary = Color(0xFFF8E8EE),
            background = Color(0xFFF9F5F6),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFFDCEDF),
            onPrimary = Color.Black,
            onSecondary = Color.Black,
            onTertiary = Color.Black,
            onBackground = Color.Black,
            onSurface = Color.Black,
            onSurfaceVariant = Color.Black,
            primaryContainer = Color(0xFFFDCEDF),
            onPrimaryContainer = Color.Black,
            secondaryContainer = Color(0xFFF8E8EE),
            onSecondaryContainer = Color.Black,
            outline = Color(0xFFF2BED1),
            outlineVariant = Color(0xFFFDCEDF)
        )
    ),
    // Theme 5: Ice Cyan & Teal (Palette 5)
    AppThemeConfig(
        name = "Ice Cyan & Teal ❄️",
        isDark = false,
        colorScheme = lightColorScheme(
            primary = Color(0xFF71C9CE),
            secondary = Color(0xFFA6E3E9),
            tertiary = Color(0xFFCBF1F5),
            background = Color(0xFFE3FDFD),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFCBF1F5),
            onPrimary = Color.Black,
            onSecondary = Color.Black,
            onTertiary = Color.Black,
            onBackground = Color.Black,
            onSurface = Color.Black,
            onSurfaceVariant = Color.Black,
            primaryContainer = Color(0xFFA6E3E9),
            onPrimaryContainer = Color.Black,
            secondaryContainer = Color(0xFFCBF1F5),
            onSecondaryContainer = Color.Black,
            outline = Color(0xFF71C9CE),
            outlineVariant = Color(0xFFA6E3E9)
        )
    ),
    // Theme 6: Warm Lilac (Palette 6)
    AppThemeConfig(
        name = "Warm Lilac ☁️",
        isDark = false,
        colorScheme = lightColorScheme(
            primary = Color(0xFF8785A2),
            secondary = Color(0xFFFFC7C7),
            tertiary = Color(0xFFFFE2E2),
            background = Color(0xFFF6F6F6),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFFFE2E2),
            onPrimary = Color.White,
            onSecondary = Color.Black,
            onTertiary = Color.Black,
            onBackground = Color.Black,
            onSurface = Color.Black,
            onSurfaceVariant = Color.Black,
            primaryContainer = Color(0xFFFFC7C7),
            onPrimaryContainer = Color.Black,
            secondaryContainer = Color(0xFFFFE2E2),
            onSecondaryContainer = Color.Black,
            outline = Color(0xFF8785A2),
            outlineVariant = Color(0xFFFFC7C7)
        )
    ),
    // Theme 7: Dreamy Periwinkle (Palette 7)
    AppThemeConfig(
        name = "Dreamy Periwinkle 🦄",
        isDark = false,
        colorScheme = lightColorScheme(
            primary = Color(0xFFB1B2FF),
            secondary = Color(0xFFAAC4FF),
            tertiary = Color(0xFFD2DAFF),
            background = Color(0xFFEEF1FF),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFD2DAFF),
            onPrimary = Color.Black,
            onSecondary = Color.Black,
            onTertiary = Color.Black,
            onBackground = Color.Black,
            onSurface = Color.Black,
            onSurfaceVariant = Color.Black,
            primaryContainer = Color(0xFFAAC4FF),
            onPrimaryContainer = Color.Black,
            secondaryContainer = Color(0xFFD2DAFF),
            onSecondaryContainer = Color.Black,
            outline = Color(0xFFB1B2FF),
            outlineVariant = Color(0xFFAAC4FF)
        )
    ),
    // Theme 8: Soft Violet Purple (Palette 8)
    AppThemeConfig(
        name = "Soft Violet Purple 👾",
        isDark = false,
        colorScheme = lightColorScheme(
            primary = Color(0xFF7469B6),
            secondary = Color(0xFFAD88C6),
            tertiary = Color(0xFFE1AFD1),
            background = Color(0xFFFFE6E6),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFE1AFD1),
            onPrimary = Color.White,
            onSecondary = Color.Black,
            onTertiary = Color.Black,
            onBackground = Color.Black,
            onSurface = Color.Black,
            onSurfaceVariant = Color.Black,
            primaryContainer = Color(0xFFAD88C6),
            onPrimaryContainer = Color.Black,
            secondaryContainer = Color(0xFFE1AFD1),
            onSecondaryContainer = Color.Black,
            outline = Color(0xFF7469B6),
            outlineVariant = Color(0xFFAD88C6)
        )
    ),
    // Theme 9: Misty Sage Grey (Palette 9)
    AppThemeConfig(
        name = "Misty Sage Grey 🍵",
        isDark = false,
        colorScheme = lightColorScheme(
            primary = Color(0xFFC4DFDF),
            secondary = Color(0xFFD2E9E9),
            tertiary = Color(0xFFE3F4F4),
            background = Color(0xFFF8F6F4),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFE3F4F4),
            onPrimary = Color.Black,
            onSecondary = Color.Black,
            onTertiary = Color.Black,
            onBackground = Color.Black,
            onSurface = Color.Black,
            onSurfaceVariant = Color.Black,
            primaryContainer = Color(0xFFD2E9E9),
            onPrimaryContainer = Color.Black,
            secondaryContainer = Color(0xFFE3F4F4),
            onSecondaryContainer = Color.Black,
            outline = Color(0xFFC4DFDF),
            outlineVariant = Color(0xFFD2E9E9)
        )
    ),
    // Theme 10: Soft Steel Blue (Palette 10)
    AppThemeConfig(
        name = "Soft Steel Blue 💎",
        isDark = false,
        colorScheme = lightColorScheme(
            primary = Color(0xFF769FCD),
            secondary = Color(0xFFB9D7EA),
            tertiary = Color(0xFFD6E6F2),
            background = Color(0xFFF7FBFC),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFD6E6F2),
            onPrimary = Color.White,
            onSecondary = Color.Black,
            onTertiary = Color.Black,
            onBackground = Color.Black,
            onSurface = Color.Black,
            onSurfaceVariant = Color.Black,
            primaryContainer = Color(0xFFB9D7EA),
            onPrimaryContainer = Color.Black,
            secondaryContainer = Color(0xFFD6E6F2),
            onSecondaryContainer = Color.Black,
            outline = Color(0xFF769FCD),
            outlineVariant = Color(0xFFB9D7EA)
        )
    ),
    // Theme 11: Vampire Crimson (Palette 11)
    AppThemeConfig(
        name = "Vampire Crimson 🩸",
        isDark = true,
        colorScheme = darkColorScheme(
            primary = Color(0xFFFF0000),
            secondary = Color(0xFF950101),
            tertiary = Color(0xFF3D0000),
            background = Color(0xFF000000),
            surface = Color(0xFF160101),
            surfaceVariant = Color(0xFF260202),
            onPrimary = Color.White,
            onSecondary = Color.White,
            onTertiary = Color.White,
            onBackground = Color.White,
            onSurface = Color.White,
            onSurfaceVariant = Color.White,
            primaryContainer = Color(0xFFFF0000),
            onPrimaryContainer = Color.White,
            secondaryContainer = Color(0xFF950101),
            onSecondaryContainer = Color.White,
            outline = Color(0xFFFF0000),
            outlineVariant = Color(0xFF950101)
        )
    ),
    // Theme 12: Business Slate (Palette 12)
    AppThemeConfig(
        name = "Business Slate 👔",
        isDark = true,
        colorScheme = darkColorScheme(
            primary = Color(0xFFC9D6DF),
            secondary = Color(0xFF52616B),
            tertiary = Color(0xFFF0F5F9),
            background = Color(0xFF1E2022),
            surface = Color(0xFF2B2E30),
            surfaceVariant = Color(0xFF3B3E41),
            onPrimary = Color.Black,
            onSecondary = Color.White,
            onTertiary = Color.Black,
            onBackground = Color.White,
            onSurface = Color.White,
            onSurfaceVariant = Color.White,
            primaryContainer = Color(0xFF52616B),
            onPrimaryContainer = Color.White,
            secondaryContainer = Color(0xFFF0F5F9),
            onSecondaryContainer = Color.Black,
            outline = Color(0xFFC9D6DF),
            outlineVariant = Color(0xFF52616B)
        )
    ),
    // Theme 13: Deep Deep Navy (Palette 13)
    AppThemeConfig(
        name = "Deep Deep Navy 🌌",
        isDark = true,
        colorScheme = darkColorScheme(
            primary = Color(0xFF2C74B3),
            secondary = Color(0xFF205295),
            tertiary = Color(0xFF144272),
            background = Color(0xFF0A2647),
            surface = Color(0xFF103159),
            surfaceVariant = Color(0xFF184478),
            onPrimary = Color.White,
            onSecondary = Color.White,
            onTertiary = Color.White,
            onBackground = Color.White,
            onSurface = Color.White,
            onSurfaceVariant = Color.White,
            primaryContainer = Color(0xFF2C74B3),
            onPrimaryContainer = Color.White,
            secondaryContainer = Color(0xFF205295),
            onSecondaryContainer = Color.White,
            outline = Color(0xFF2C74B3),
            outlineVariant = Color(0xFF205295)
        )
    ),
    // Theme 14: Neon Cyber Purple (Palette 14)
    AppThemeConfig(
        name = "Neon Cyber Purple 🔮",
        isDark = true,
        colorScheme = darkColorScheme(
            primary = Color(0xFFBC6FF1),
            secondary = Color(0xFF892CDC),
            tertiary = Color(0xFF52057B),
            background = Color(0xFF000000),
            surface = Color(0xFF180224),
            surfaceVariant = Color(0xFF28033A),
            onPrimary = Color.Black,
            onSecondary = Color.White,
            onTertiary = Color.White,
            onBackground = Color.White,
            onSurface = Color.White,
            onSurfaceVariant = Color.White,
            primaryContainer = Color(0xFFBC6FF1),
            onPrimaryContainer = Color.Black,
            secondaryContainer = Color(0xFF892CDC),
            onSecondaryContainer = Color.White,
            outline = Color(0xFFBC6FF1),
            outlineVariant = Color(0xFF892CDC)
        )
    ),
    // Theme 15: Cyber Teal Navy (Palette 15)
    AppThemeConfig(
        name = "Cyber Teal Navy 🦾",
        isDark = true,
        colorScheme = darkColorScheme(
            primary = Color(0xFF00A8CC),
            secondary = Color(0xFF0C7B93),
            tertiary = Color(0xFF27496D),
            background = Color(0xFF142850),
            surface = Color(0xFF1A3469),
            surfaceVariant = Color(0xFF244482),
            onPrimary = Color.Black,
            onSecondary = Color.White,
            onTertiary = Color.White,
            onBackground = Color.White,
            onSurface = Color.White,
            onSurfaceVariant = Color.White,
            primaryContainer = Color(0xFF00A8CC),
            onPrimaryContainer = Color.Black,
            secondaryContainer = Color(0xFF0C7B93),
            onSecondaryContainer = Color.White,
            outline = Color(0xFF00A8CC),
            outlineVariant = Color(0xFF0C7B93)
        )
    )
)

@Composable
fun MyApplicationTheme(
    themeIndex: Int = 0,
    content: @Composable () -> Unit
) {
    // Select the chosen theme index, clamp it to protect against boundaries
    val activeConfig = AppThemesList.getOrElse(themeIndex) { AppThemesList[0] }

    MaterialTheme(
        colorScheme = activeConfig.colorScheme,
        typography = Typography,
        content = content
    )
}
