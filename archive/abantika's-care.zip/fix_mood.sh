sed -i '/val isDark = /d' app/src/main/java/com/example/ui/screens/CareDashboard.kt
sed -i '2643,2654d' app/src/main/java/com/example/ui/screens/CareDashboard.kt
sed -i '2643i\    return baseColor' app/src/main/java/com/example/ui/screens/CareDashboard.kt
