sed -i 's/Color(0xFFFDE2E4)/MaterialTheme.colorScheme.tertiaryContainer/g' app/src/main/java/com/example/ui/screens/CareDashboard.kt
sed -i 's/Color(0xFFFFF8E1)/MaterialTheme.colorScheme.primaryContainer/g' app/src/main/java/com/example/ui/screens/CareDashboard.kt
sed -i 's/Color(0xFFD6C5F0)/MaterialTheme.colorScheme.secondary/g' app/src/main/java/com/example/ui/screens/CareDashboard.kt
sed -i 's/Color(0xFFFFB7B2)/MaterialTheme.colorScheme.primary/g' app/src/main/java/com/example/ui/screens/CareDashboard.kt
sed -i 's/Color(0xFFB5EAD7)/MaterialTheme.colorScheme.tertiary/g' app/src/main/java/com/example/ui/screens/CareDashboard.kt
sed -i 's/Color(0xFFE1F5FE)/MaterialTheme.colorScheme.primaryContainer/g' app/src/main/java/com/example/ui/screens/CareDashboard.kt
sed -i 's/Color(0xFFFFF9C4)/MaterialTheme.colorScheme.secondaryContainer/g' app/src/main/java/com/example/ui/screens/CareDashboard.kt
sed -i 's/Color(0xFFFFCC80)/MaterialTheme.colorScheme.tertiaryContainer/g' app/src/main/java/com/example/ui/screens/CareDashboard.kt
