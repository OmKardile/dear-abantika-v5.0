sed -i 's/androidx.compose.ui.graphics.toArgb(baseColor)/baseColor.toArgb()/g' app/src/main/java/com/example/ui/screens/CareDashboard.kt
sed -i 's/androidx.compose.ui.graphics.toArgb(MaterialTheme.colorScheme.surface)/MaterialTheme.colorScheme.surface.toArgb()/g' app/src/main/java/com/example/ui/screens/CareDashboard.kt
